<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        //load library validatin
        $this->load->library('form_validation');
        $this->load->model("Admin_model");
    }

    public function index()
    {
   
        if ($this->check_session()) {

            $title['data'] = "Data Master";
            $result['data'] = $this->Admin_model->getData();
            $this->load->view('layout/template', $title);
            $this->load->view('tables/data_master', $result);
            $this->load->view('layout/footer');
        } else {
            $this->load->view('login');
        }
    }

    public function check_session()
    {
        return $this->session->has_userdata('username');
    }

    public function login()
    {

        $this->form_validation->set_rules("username", "Username", "required", array("required" => "Mohon isi username anda!"));
        $this->form_validation->set_rules("password", "Password", "required", array("required" => "Mohon isi password anda!"));

        $username = $this->input->post("username");
        $password = $this->input->post("password");

        if ($this->form_validation->run() == false) {

            $this->load->view('login');
        } else {
            $user = $this->db->get_where("tb_users", array("username" => $username))->first_row();

            if ($user && md5($password) === $user->password) {
                $dataLogin = array(
                    "username" => $user->username,
                    "password" => $user->password,
                    "id_admin" => $user->id_admin,
                    "foto_profil" => $user->foto_profil
                );
                $this->session->set_userdata($dataLogin);
                redirect('/admin');
            }else {
                $this->session->set_flashdata("message", '<div class="alert alert-danger" role="alert">Username atau password salah! silahkan coba lagi</div>');
                redirect('/admin');
            }
        }
    }

    public function logout()
    {
        $array_items = array('username', 'password');

        if ($this->Admin_model->update_last_login_user($this->session->userdata('id_user'))){
            $this->session->unset_userdata($array_items);
            redirect('/admin');
            // $this->load->view('login');
        }

    }
}
