<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    public function __construct()
    {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();

        /*load database libray manually*/
        // $this->load->database();

        /*load Model*/
        $this->load->model('Admin_model'); //load model Admin_model
    }

    public function get_data()
    {
        $result = $this->Admin_model->getData();
        foreach($result as $d => $rs)
        {
            $hasil[] = array(
            'no' => $d += 1, 
            'id_barang' => $rs->id_barang, 
            'nama_barang' => $rs->nama_barang, 
            'jenis_barang' => $rs->jenis_barang, 
            'jumlah_barang' => $rs->jumlah_barang, 
            'kondisi_barang' => $rs->kondisi_barang, 
            'lokasi_barang' => $rs->lokasi_barang, 
            'pengguna_barang' => $rs->pengguna_barang, 
            'merk_barang' => $rs->merk_barang, 
            'kategori_barang' => $rs->kategori_barang, 
            );
        }
        $data['data'] = $hasil;

        $this->output->set_content_type('application/json')->set_output(json_encode($data));
        
    }

    public function index()
    {
        $title['data'] = "Dashboard";
        $result['data'] = $result = $this->Admin_model->getData();
        $this->load->view('layout/template', $title);
        $this->load->view('tables/dashboard', $result);
        $this->load->view('layout/footer');
    }

    public function dashboard()
    {
        $title['data'] = "Dashboard";
       // $result['data'] = $result = $this->Admin_model->getData();
        $this->load->view('layout/template', $title);
        $this->load->view('tables/dashboard');
        $this->load->view('layout/footer');
    }

    public function get_data_dashboard(){
        $result['data'] = $result = $this->Admin_model->getData();

        $this->output->set_content_type('application/json')->set_output(json_encode($result));
        
    }

    public function create()
    {
        $title['data'] = "Tambah Data";
        $this->load->view('layout/template', $title);
        $this->load->view('form/form_tambah_data');
        $this->load->view('layout/footer');
    }

    public function inputData()
    {
        $put = $this->input->post(); // $this->input->post(); berfungsi untuk menangkap atau mendapatkan data dari tag <form></form>
        $put['nama_barang'] = htmlspecialchars($put['nama_barang']);
        $result = $this->Admin_model->insertData($put);
        if ($result) {
            $this->session->set_flashdata("message", '<div class="alert alert-success" role="alert">Data Berhasil Ditambahkan!</div>');
            return redirect("/admin");
        } else {
            echo "Data tidak masuk";
        }
    }

    public function detail($id = 0)
    {
        $title['data'] = "Detail Barang";
        $dataResult['dataDetail'] = $this->Admin_model->getData($id);
        $this->load->view('layout/template', $title);
        $this->load->view('form/form_detail_barang', $dataResult);
        $this->load->view('layout/footer');
    }

    public function delete($id = 0)
    {
        if ($id <= 0) return;
        $resultDelete = $this->Admin_model->deleteData($id);
        $this->session->set_flashdata("message", '<div class="alert alert-success" role="alert">Data Berhasil Dihapus!</div>');
        if ($resultDelete) {
            redirect(base_url()."/admin");
        }
    }

    public function update($id = 0)
    {
        $title['data'] = "Update Data";
        $result['dataDetail'] = $this->Admin_model->getData($id);
        $this->load->view('layout/template', $title); //$this->load->view('layout/template'); berfungsi untuk menampilkan atau merender view.
        $this->load->view('form/form_update_barang', $result); //$this->load->view('layout/template'); berfungsi untuk menampilkan atau merender view sekaligus mengirim data ke file view tersebut.
        $this->load->view('layout/footer');
    }

    public function update_data($id = 0)
    {
        $respon = $this->Admin_model->update_data($id, $this->input->post());
        if ($respon) {
            $this->session->set_flashdata("message", '<div class="alert alert-success" role="alert">Data Berhasil Diubah</div>');
            return redirect(base_url()."/admin");
        } else {
            echo "Gagal";
        }
    }

    public function peminjaman()
    {
        $title['data'] = "Peminjaman";
       // $result['data'] = $this->Admin_model->getData();
        $this->load->view('layout/template', $title);
        $this->load->view('tables/peminjaman_barang');
        $this->load->view('layout/footer');
    }

    public function get_data_table_peminjaman()
    {
        $result = $this->Admin_model->getData();

        foreach($result as $i => $field){

            $hasil[] = array(
                "no" => $i += 1,
                "id_barang" => $field->id_barang,
                "nama_barang" => $field->nama_barang,
                "jenis_barang" => $field->jenis_barang,
                "jumlah_barang" => $field->jumlah_barang,
                "kondisi_barang" => $field->kondisi_barang,
                "lokasi_barang" => $field->lokasi_barang,
                "pengguna_barang" => $field->pengguna_barang,
                "merk_barang" => $field->merk_barang,
                "kategori_barang" => $field->kategori_barang,
               
            );

        }

        $data['data'] = $hasil;


        $this->output->set_content_type('application/json')->set_output(json_encode($data));

        
    }

    public function tambah_peminjaman($id_barang)
    {
        date_default_timezone_set("Asia/Jakarta");
        $data = array(
            "id_mahasiswa_peminjam" => htmlspecialchars($this->input->post("id_mahasiswa")),
            "id_barang" => htmlspecialchars($id_barang),
            "jumlah_peminjaman" => htmlspecialchars($this->input->post("jumlah_peminjaman")),
            "tanggal_peminjaman" => date('l d-F-Y H:i:s'),
            "status" => "Sedang Dipinjam",
            "id_admin" => $this->session->userdata('id_admin')
    );
        $result = $this->Admin_model->insert_data_peminjaman($data);
        if ($result) {
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Berhasil Ditambahkan</div>');
            redirect("/admin/transaksi_peminjaman");
        }
    }

    public function form_peminjaman($id = 0)
    {
        $title['data'] = "Data Peminjaman";
        $result['dataDetail'] = $this->Admin_model->getData($id);
        $this->load->view('layout/template', $title);
        $this->load->view('form/form_peminjaman', $result);
        $this->load->view('layout/footer');
    }

    public function transaksi_peminjaman()
    {
        $title['data'] = "Transaksi Peminjaman";
       // $result["data"] = $this->Admin_model->get_data_transaksi_peminjaman();
        //echo json_encode($result);
        $this->load->view('layout/template', $title);
        $this->load->view('tables/transaksi_peminjaman');
        $this->load->view('layout/footer');
    }

    public function get_data_transaksi_peminjaman_as_json()
    {
        $result = $this->Admin_model->get_data_transaksi_peminjaman();

        foreach($result as $i => $field){

            $hasil[] = array(
                "no" => $i += 1,
                "jumlah_peminjaman" => $field->jumlah_peminjaman,
                "id_peminjaman" => $field->id_peminjaman,
                "tanggal_peminjaman" => $field->tanggal_peminjaman,
                "status" => $field->status,
                "nama" => $field->nama,
                "nim" => $field->nim,
                "nama_kelas" => $field->nama_kelas,
                "nama_prodi" => $field->nama_prodi,
                "nama_barang" => $field->nama_barang,
               
            );

        }

        $data['data'] = $hasil;

        $this->output->set_content_type('application/json')->set_output(json_encode($data));

    }

    public function form_pengembalian($id_peminjaman = 0)
    {
        $title['data'] = "Pengembalian";
        $result["dataDetail"] = $this->Admin_model->get_data_form_pengembalian($id_peminjaman);
     //   echo json_encode($result);
        $this->load->view('layout/template', $title);
        $this->load->view('form/form_pengembalian', $result);
        $this->load->view('layout/footer');
    }

    public function tambah_pengembalian($id_peminjaman = 0, $id_barang = 0)
    {
        date_default_timezone_set("Asia/Jakarta");
        $data = array( 
            "id_mahasiswa_pengembali" => $this->input->post('id_mahasiswa_pengembali'),
            "id_barang" => $id_barang,
            "jumlah_pengembalian" => $this->input->post('jumlah_pengembalian'),
            "id_peminjaman" => $id_peminjaman,
            "tanggal_pengembalian" => date('l d-F-Y H:i:s')
        );
       
        $result = $this->Admin_model->insert_data_pengembalian($data);
        if ($result) {
            redirect("/admin");
        } else {
            echo "Gagal Transaksi Pengembalian";
        }
    }

    public function transaksi_pengembalian()
    {
        $title['data'] = "Transaksi Pengembalian";
        //$result["data"] = $this->Admin_model->get_data_transaksi_pengembalian();
        $this->load->view('layout/template', $title);
        $this->load->view('tables/transaksi_pengembalian');
        $this->load->view('layout/footer');
    }

    public function get_data_transaksi_pengembalian_as_json()
    {
        $result = $this->Admin_model->get_data_transaksi_pengembalian();

        if ($result != null){
            foreach($result as $index => $data){

                $hasil[] = [
                    "no" => $index += 1,
                    "jumlah_pengembalian" => $data->jumlah_pengembalian,
                    "tanggal_pengembalian" => $data->tanggal_pengembalian,
                    "nama_barang" => $data->nama_barang,
                    "nama_prodi" => $data->nama_prodi,
                    "nama" => $data->nama,
                    "nim" => $data->nim
                ];
    
            }
            $values['status'] = 200;
            $values['data'] = $hasil;
        }else {
            $values['status'] = 400;
            $values['message'] = "Data kosong";

        }

        $this->output->set_content_type('application/json')->set_output(json_encode($values));
        
    }

    public function history_transaksi()
    {
        $title['data'] = "Riwayat Transaksi";
        //$result['data_result'] = $this->Admin_model->get_history_transaksi();
        $this->load->view('layout/template', $title);
        $this->load->view('tables/history_transaksi');
        $this->load->view('layout/footer');
    }

    public function get_histori_transaksi_as_json()
    {
        
        $result = $this->Admin_model->get_history_transaksi();

        foreach($result as $d => $rs)
        {
            $hasil[] = array(
            'no' => $d += 1, 
            'nama_peminjam' => $rs->nama_peminjam, 
            'nim_peminjam' => $rs->nim_peminjam, 
            'nama_pengembali' => $rs->nama_pengembali, 
            'nim_pengembali' => $rs->nim_pengembali, 
            'nama_barang' => $rs->nama_barang,
            'tanggal_peminjaman' => $rs->tanggal_peminjaman, 
            'tanggal_pengembalian' => $rs->tanggal_pengembalian, 
            'jumlah_peminjaman' => $rs->jumlah_peminjaman, 
            'jumlah_pengembalian' => $rs->jumlah_pengembalian, 
            ); 
        }
        $data['status'] = 200;
        $data['data'] = $hasil;

        $this->output->set_content_type('application/json')->set_output(json_encode($data));
    }

    public function profile()
    {
        $title['data'] = "Profil";
        $this->load->view('layout/template', $title);
        $this->load->view('profil');
        $this->load->view('layout/footer');
    }

    public function get_nama_mahasiswa()
    {
        $result = $this->Admin_model->get_mahasiswa_name();
        $this->output->set_content_type('application/json')->set_output(json_encode($result));        
    }

    public function get_data_peminjam()
    {
        $name = $this->input->get('nama');
        $result = $this->Admin_model->get_data_peminjam($name);

        if ($result){
            $data['status'] = "200";
            $data['data'] = $result;
        }else {
            $data['status'] = 404;
            $data['message'] = "Data Tidak Ditemukan";
        }

       $this->output->set_content_type('application/json')->set_output(json_encode($data));
    }
    
}
