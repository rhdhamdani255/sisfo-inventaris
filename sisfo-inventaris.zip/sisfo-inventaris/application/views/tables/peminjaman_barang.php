<main id="main" class="main">

    <h1>Peminjaman Barang </h1>
    <h3>Input Peminjaman Barang</h3>

   

    <!-- Inisialisasi Datatables -->

    <!-- End Inisialisasi Datatables -->

    <table class="table" id="tablepeminjaman">
        <thead class="table-dark">
            <tr class="align-middle">
                <th class="bg-primary">No</th>
                <th class="bg-primary">Nama Barang</th>
                <th class="bg-primary">Jenis Barang</th>
                <th class="bg-primary">Jumlah</th>
                <th class="bg-primary">Kondisi</th>
                <th class="bg-primary">Lokasi</th>
                <th class="bg-primary">Pengguna</th>
                <th class="bg-primary">Merk Barang</th>
                <th class="bg-primary">Kategori</th>
                <th class="bg-primary">Action</th>
            </tr>
        </thead>

        <tbody>
            <!-- <?php
                    $no = 1;
                    foreach ($data as $value) : ?>
                <tr class="text-center">
                    <td><?= $no++ ?></td>
                    <td><?= $value->nama_barang ?></td>
                    <td><?= $value->jenis_barang ?></td>
                    <td><?= $value->jumlah_barang ?></td>
                    <td><?= $value->kondisi_barang ?></td>
                    <td><?= $value->lokasi_barang ?></td>
                    <td><?= $value->pengguna_barang ?></td>
                    <td><?= $value->merk_barang ?></td>
                    <td><?= $value->kategori_barang ?></td>
                    <td>
                        <a class="btn btn-success me-1" type="submit" href="<?= base_url() ?>admin/form_peminjaman/<?= $value->id_barang ?>">Pinjam</a>
                    </td>
                </tr>
            <?php endforeach; ?> -->
        </tbody>
    </table>

    <a href="<?= base_url(); ?>admin" class="btn btn-warning mt-4">Kembali</a>

</main><!-- End #main -->