<main id="main" class="main">

    <h1>Histori Transaksi </h1>
    <h3>Daftar Histori Transaksi</h3>

    <!-- <div class="alert alert-success" role="alert">
        A simple success alert—check it out!
    </div> -->

    <!-- Inisialisasi Datatables -->

    <!-- End Inisialisasi Datatables -->

    <table class="table" id="table_histori_transaksi">
        <thead class="table-dark">
            <tr class="align-middle">
                <th class="bg-primary">No</th>
                <th class="bg-primary">Nama Peminjam</th>
                <th class="bg-primary">NIM Peminjam</th>
                <th class="bg-primary">Nama Barang</th>
                <th class="bg-primary">Jumlah Peminjaman</th>
                <th class="bg-primary">Tanggal Peminjaman</th>


                <th class="bg-primary">Nama Pengembali</th>
                <th class="bg-primary">NIM Pengembali</th>
                <th class="bg-primary">Nama Barang</th>
                <th class="bg-primary">Jumlah Pengembalian</th>
                <th class="bg-primary">Tanggal Pengembalian</th>
                
            </tr>
        </thead>

        <tbody>
            <!-- <?php
            $no = 1;
            foreach ($data_result as $value) : ?>
                <tr class="text-center">
                    <td><?= $no++ ?></td>
                    <td><?= $value->nama_peminjam ?></td>
                    <td><?= $value->nim_peminjam ?></td>
                    <td><?= $value->nama_barang ?></td>
                    <td><?= $value->jumlah_peminjaman ?></td>
                    <td><?= $value->tanggal_peminjaman ?></td>
                    <td>||</td>
                    <td><?= $value->nama_pengembali ?></td>
                    <td><?= $value->nim_pengembali ?></td>
                    <td><?= $value->nama_barang ?></td>
                    <td><?= $value->jumlah_pengembalian ?></td>
                    <td><?= $value->tanggal_pengembalian ?></td>
                    <td>
                        <?php if ($value->jumlah_peminjaman > 0) : ?>
                            <a class="btn btn-warning" type="submit" href="<?php base_url() ?>form_pengembalian/<?= $value->id_peminjaman ?>">Pengembalian</a>
                        <?php else : ?>
                            <a class="btn btn-success">Sudah Dikembalikan</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?> -->
        </tbody>
    </table>

    <a href="<?= base_url(); ?>admin" class="btn btn-warning mt-4">Kembali</a>

</main><!-- End #main -->