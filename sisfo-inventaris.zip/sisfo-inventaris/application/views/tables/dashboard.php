<main id="main" class="main">

    <h1>DASHBOARD </h1>
    <h3>Daftar Barang Tersedia</h3>

    <?= $this->session->flashdata("message"); ?>

    <!-- Inisialisasi Datatables -->

    <!-- End Inisialisasi Datatables -->

    <table class="table" id="tabledashboard">
        <thead class="table-dark mytable">
            <tr class="align-middle">
                <th class="bg-primary">No</th>
                <th class="bg-primary">Nama Barang</th>
                <th class="bg-primary">Jenis Barang</th>
                <th class="bg-primary">Tersedia</th>
                <th class="bg-primary">Kondisi Barang</th>
                <th class="bg-primary">Lokasi</th>
                <th class="bg-primary">Pengguna</th>
                <th class="bg-primary">Merk Barang</th>
                <th class="bg-primary">Kategori</th>
            </tr>
        </thead>

        <tbody>
            <!-- <?php
            $no = 1;
            foreach ($data as $value) : ?>
                <tr class="text-center">
                    <td><?= $no++ ?></td>
                    <td><?= $value->nama_barang ?></td>
                    <td><?= $value->jenis_barang ?></td>
                    <td><?= $value->jumlah_barang ?></td>
                    <td><?= $value->kondisi_barang ?></td>
                    <td><?= $value->lokasi_barang ?></td>
                    <td><?= $value->pengguna_barang ?></td>
                    <td><?= $value->merk_barang ?></td>
                    <td><?= $value->kategori_barang ?></td>
  
                </tr>
            <?php endforeach; ?> -->

        </tbody>
    </table>

</main><!-- End #main -->