<main id="main" class="main">

    <h1>Transaksi Peminjaman </h1>
    <h3>Daftar Transaksi Peminjaman</h3>
    <?= $this->session->flashdata('message'); ?>
    <!-- <div class="alert alert-success" role="alert">
        A simple success alert—check it out!
    </div> -->

    <!-- Inisialisasi Datatables -->


    <!-- End Inisialisasi Datatables -->

    <div class="container">
        <div class="row">
            <div class="col">
            
    <table class="table w-auto" id="tabletransaksipeminjaman">
        <thead class="table-dark">
            <tr class="align-center">
                <th class="bg-primary">No</th>
                <th class="bg-primary">Nama Peminjam</th>
                <th class="bg-primary">NIM Peminjam</th>
                <th class="bg-primary">Prodi Peminjam</th>
                <th class="bg-primary">Kelas Peminjam</th>
                <th class="bg-primary">Nama Barang</th>
                <th class="bg-primary">Jumlah Peminjaman</th>
                <th class="bg-primary">Status</th>
                <th class="bg-primary">Tanggal Peminjaman</th>
                <th class="bg-primary">Aksi</th>
            </tr>
        </thead>

        <tbody>
            <!-- <?php
            $no = 1;
            foreach ($data as $value) : ?>
                <tr class="text-center">
                    <td><?= $no++ ?></td>
                    <td><?= $value->nama ?></td>
                    <td><?= $value->nim ?></td>
                    <td><?= $value->nama_prodi ?></td>
                    <td><?= $value->nama_kelas ?></td>
                    <td><?= $value->nama_barang ?></td>
                    <td><?= $value->jumlah_peminjaman ?></td>
                    <td><?= $value->status ?></td>
                    <td><?= $value->tanggal_peminjaman ?></td>
                    <td>
                        <?php if ($value->status == "Sedang Dipinjam") : ?>
                            <a class="btn btn-warning btn-sm" type="submit" href="<?php base_url() ?>form_pengembalian/<?= $value->id_peminjaman ?>">Pengembalian</a>
                        <?php else : ?>
                            <a class="btn btn-success btn-sm">Sudah Dikembalikan</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?> -->
        </tbody>
    </table>

            </div>
        </div>
    </div>

    <a href="<?= base_url(); ?>admin" class="btn btn-warning mt-4">Kembali</a>

</main><!-- End #main -->