<main id="main" class="main">

    <h1>Transaksi Pengembalian </h1>
    <h3>Daftar Transaksi Pengembalian</h3>

    <!-- <div class="alert alert-success" role="alert">
        A simple success alert—check it out!
    </div> -->

    <!-- Inisialisasi Datatables -->

    <!-- End Inisialisasi Datatables -->

    <table class="table" id="tabletransaksipengembalian">
        <thead class="table-dark">
            <tr class="align-middle">
                <th class="bg-primary">No</th>
                <th class="bg-primary">Nama Pengembali</th>
                <th class="bg-primary">NIM Pengembali</th>
                <th class="bg-primary">Prodi Pengembali</th>
                <th class="bg-primary">Barang Kembali</th>
                <th class="bg-primary">Jumlah Pengembalian</th>
                <th class="bg-primary">Tanggal Pengembalian</th>
            </tr>
        </thead>

        <tbody>
            <!-- <?php
            $no = 1;
            foreach ($data as $value) : ?>
                <tr class="text-center">
                    <td><?= $no++ ?></td>
                    <td><?= $value->nama ?></td>
                    <td><?= $value->nim ?></td>
                    <td><?= $value->nama_prodi ?></td>
                    <td><?= $value->nama_barang ?></td>
                    <td><?= $value->jumlah_pengembalian ?></td>
                    <td><?= $value->tanggal_pengembalian ?></td>
          
                    <td>
                        <?php if ($value->jumlah_peminjaman > 0) : ?>
                            <a class="btn btn-warning" type="submit" href="<?php base_url() ?>form_pengembalian/<?= $value->id_peminjaman ?>">Pengembalian</a>
                        <?php else : ?>
                            <a class="btn btn-success">Sudah Dikembalikan</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?> -->
        </tbody>
    </table>

    <a href="<?= base_url(); ?>admin" class="btn btn-warning mt-4">Kembali</a>

</main><!-- End #main -->