<main id="main" class="main">

    <div class="container">
    <h1>Tambah Peminjaman</h1>
    <h3>Masukan Data Peminjaman Barang</h3>

  
    </div>
    <div class="container">
        <div class="row">

            <div class="col col-lg-6">

                <form action="<?= base_url() ?>admin/tambah_peminjaman/<?= $dataDetail[0]->id_barang ?>" method="POST">

                    <div class="form-group fs-5 pb-4">
                        <select class="dropdown fs-5 w-100" id="nama_peminjam" onchange="setDataPeminjam('peminjaman')" name="nama_peminjam" required>
                            <!-- <option value="" disabled selected>Nama Peminjam</option> -->
                            <!-- <option value="Teknik Pengolahan Sawit" class="dropdown-item form-control">Teknik Pengolahan Sawit</option>
                            <option value="Perawatan Dan Perbaikan Mesin" class="dropdown-item form-control">Perawatan Dan Perbaikan Mesin</option>
                            <option value="Teknik Informatika" class="dropdown-item form-control">Teknik Informatika</option>
                            <option value="Administrasi Bisnis Internasional" class="dropdown-item form-control">Administrasi Bisnis Internasional</option> -->
                        </select>
                    </div>

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="text">Nama Peminjam</label>
                        <input value="" type="text" name="nama_peminjam" class="form-control" id="email" required>
                    </div> -->

                    <div class='form-group fs-5 pb-4 d-none'>
                        <label for="id_mahasiswa">ID Mahasiswa</label>
                        <input value="" type="password" name="id_mahasiswa" class="form-control" id="id_mahasiswa" required>
                    </div>

                    <div class='form-group fs-5 pb-4'>
                        <label for="jenis_barang">NIM Peminjam</label>
                        <input value="" type="text" name="nim_peminjam" class="form-control" id="nim_peminjam" required>
                    </div>

                    <div class="form-group fs-5 pb-4">
                    <select class="dropdown fs-5 w-100" id="prodi_peminjam" name="prodi_peminjam" required>
                        <option value="" disabled selected>Prodi Peminjam</option>
                        <option value="D3-Teknik Pengolahan Sawit" class="dropdown-item form-control">D3-Teknik Pengolahan Sawit</option>
                        <option value="D3-Perbaikan Dan Perawatan Mesin" class="dropdown-item form-control">D3-Perbaikan Dan Perawatan Mesin</option>
                        <option value="D3-Teknik Informatika" class="dropdown-item form-control">D3-Teknik Informatika</option>
                        <option value="D4-Administrasi Bisnis Internasional" class="dropdown-item form-control">D4-Administrasi Bisnis Internasional</option>
                        <option value="D2-Teknik Pengolahan Kelapa Sawit" class="dropdown-item form-control">D2-Teknik Pengolahan Kelapa Sawit</option>
                    </select>
                    </div>

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="kondisi_barang">Prodi Peminjam</label>
                        <input value="" type="text" name="prodi_peminjam" class="form-control" id="kondisi_barang" required>
                    </div> -->

                    <div class="form-group fs-5 pb-4">
                        <label for="jumlah_barang">Kelas Peminjam</label>
                        <input value="" type="text" name="kelas_peminjam" class="form-control" id="kelas_peminjam" required>
                    </div>

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="lokasi_barang">Angkatan</label>
                        <input value="" type="text" name="angkatan_peminjam" class="form-control" id="lokasi_barang" required>
                    </div> -->

                    <div class="form-group fs-5 pb-4">
                        <label for="lokasi_barang">Jumlah Peminjaman</label>
                        <input value="" type="number" name="jumlah_peminjaman" class="form-control" id="jumlah_peminjaman" required>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg">Tambah Peminjaman</button>

                </form>
            </div>

            <div class="col col-lg-6">
                
                <form>
                    <div class="form-group fs-5 pb-4">
                        <label for="text">Nama Barang</label>
                        <input value="<?= $dataDetail[0]->nama_barang ?>" type="text" name="nama_barang" class="form-control" id="email" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="jenis_barang">Jenis Barang</label>
                        <input value="<?= $dataDetail[0]->jenis_barang ?>" type="text" name="jenis_barang" class="form-control" id="jenis_barang" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="jumlah_barang">Jumlah Barang</label>
                        <input value="<?= $dataDetail[0]->jumlah_barang ?>" type="number" name="jumlah_barang" class="form-control" id="jumlah_barang" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="kondisi_barang">Kondisi Barang</label>
                        <input value="<?= $dataDetail[0]->kondisi_barang ?>" type="text" name="kondisi_barang" class="form-control" id="kondisi_barang" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="lokasi_barang">Lokasi Barang</label>
                        <input value="<?= $dataDetail[0]->lokasi_barang ?>" type="text" name="lokasi_barang" class="form-control" id="lokasi_barang" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="pengguna_barang">Pengguna Barang</label>
                        <input value="<?= $dataDetail[0]->pengguna_barang ?>" type="text" name="pengguna_barang" class="form-control" id="pengguna_barang" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="merk_barang">Merk Barang</label>
                        <input value="<?= $dataDetail[0]->merk_barang ?>" type="text" name="merk_barang" class="form-control" id="merk_barang" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="kategori_barang">Kategori Barang</label>
                        <input value="<?= $dataDetail[0]->kategori_barang ?>" type="text" name="kategori_barang" class="form-control" id="kategori_barang" required readonly>
                    </div>

                </form>

            </div>

        </div>
    </div>

</main><!-- End #main -->