<main id="main" class="main">

    <h1>Detail Barang</h1>
    <!-- <h3>Masukan Data Peminjaman Barang</h3> -->

    <div class="row">
        <div class="col col-lg-8">

            <form action="<?= base_url() ?>admin" method="POST">

                <div class="form-group fs-5 pb-4">
                    <label for="text">Nama Barang</label>
                    <input value="<?= $dataDetail[0]->nama_barang ?>" type="text" name="nama_barang" class="form-control" id="email" required readonly>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="jenis_barang">Jenis Barang</label>
                    <input value="<?= $dataDetail[0]->jenis_barang ?>" type="text" name="jenis_barang" class="form-control" id="jenis_barang" required readonly>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="jumlah_barang">Jumlah Barang</label>
                    <input value="<?= $dataDetail[0]->jumlah_barang ?>" type="number" name="jumlah_barang" class="form-control" id="jumlah_barang" required readonly>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="kondisi_barang">Kondisi Barang</label>
                    <input value="<?= $dataDetail[0]->kondisi_barang ?>" type="text" name="kondisi_barang" class="form-control" id="kondisi_barang" required readonly>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="lokasi_barang">Lokasi Barang</label>
                    <input value="<?= $dataDetail[0]->lokasi_barang ?>" type="text" name="lokasi_barang" class="form-control" id="lokasi_barang" required readonly>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="pengguna_barang">Pengguna Barang</label>
                    <input value="<?= $dataDetail[0]->pengguna_barang ?>" type="text" name="pengguna_barang" class="form-control" id="pengguna_barang" required readonly>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="merk_barang">Merk Barang</label>
                    <input value="<?= $dataDetail[0]->merk_barang ?>" type="text" name="merk_barang" class="form-control" id="merk_barang" required readonly>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="kategori_barang">Kategori Barang</label>
                    <input value="<?= $dataDetail[0]->kategori_barang ?>" type="text" name="kategori_barang" class="form-control" id="kategori_barang" required readonly>
                </div>

                <a href="<?= base_url() ?>admin" class="btn btn-primary btn-sm">Kembali</a>
                <a href="<?= base_url() ?>admin/delete/<?= $dataDetail[0]->id_barang ?>" class="btn btn-danger btn-sm">Hapus Data</a>

            </form>

        </div>
    </div>

</main><!-- End #main -->