<main id="main" class="main">

    <h1 class="ms-4">Pengembalian Barang</h1>
    <!-- <h3>Masukan Data Peminjaman Barang</h3> -->

    <div class="container">
        <div class="row">

            <div class="col col-lg-6">

                <h3>Data Peminjam</h3>
                <form name="data">
                    <div class="form-group fs-5 pb-4">
                        <label for="nama_peminjam">Nama Peminjam</label>
                        <input value="<?= $dataDetail[0]->nama ?>" type="text" name="nama_barang" class="form-control" id="nama_peminjam" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="nim_peminjam">NIM Peminjam</label>
                        <input value="<?= $dataDetail[0]->nim ?>" type="text" name="jenis_barang" class="form-control" id="nim_peminjam" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="prodi_peminjam">Prodi Peminjam</label>
                        <input value="<?= $dataDetail[0]->nama_prodi ?>" type="text" name="jumlah_barang" class="form-control" id="prodi_peminjam" required readonly>
                    </div>

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="kondisi_barang">Kondisi Barang</label>
                        <input value="kondisi barang" type="text" name="kondisi_barang" class="form-control" id="kondisi_barang" required readonly>
                    </div> -->

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="lokasi_barang">Lokasi Barang</label>
                        <input value="lokasi" type="text" name="lokasi_barang" class="form-control" id="lokasi_barang" required readonly>
                    </div> -->

                    <div class="form-group fs-5 pb-4">
                        <label for="jumlah_peminjaman">Jumlah Peminjaman</label>
                        <input value="<?= $dataDetail[0]->jumlah_peminjaman ?>" type="number" name="pengguna_barang" class="form-control" id="jumlah_peminjaman" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="tanggal_peminjaman">Tanggal Peminjaman</label>
                        <input value="<?= $dataDetail[0]->tanggal_peminjaman ?>" type="text" name="merk_barang" class="form-control" id="tanggal_peminjaman" required readonly>
                    </div>


                </form> <!-- End Data Barang -->

                <h3>Masukan Data Pengembali</h3>

                <div class="col-12 mb-4">
                    <div class="form-check">
                       <input class="form-check-input" type="checkbox" name="remember" value="true" id="check_orang_yg_sama" onclick="setSamePerson('<?= $dataDetail[0]->nama ?>', '<?= $dataDetail[0]->nim ?>', '<?= $dataDetail[0]->nama_prodi ?>', '<?= $dataDetail[0]->nama_kelas ?>', '<?= $dataDetail[0]->jumlah_peminjaman ?>', '<?= $dataDetail[0]->id_mahasiswa_peminjam ?>')">
                       <label class="form-check-label" for="rememberMe">Pengembali Orang Yang Sama</label>
                    </div>
                </div>

                <form name="data" action="<?= base_url() ?>admin/tambah_pengembalian/<?= $dataDetail[0]->id_peminjaman ?>/<?= $dataDetail[0]->id_barang ?>" method="POST">

                <div class="form-group fs-5 pb-4">
                        <select class="dropdown fs-5 w-100" id="nama_pengembali" onchange="setDataPeminjam('pengembalian')" required>
                            <!-- <option value="" disabled selected>Nama Peminjam</option> -->
                            <!-- <option value="Teknik Pengolahan Sawit" class="dropdown-item form-control">Teknik Pengolahan Sawit</option>
                            <option value="Perawatan Dan Perbaikan Mesin" class="dropdown-item form-control">Perawatan Dan Perbaikan Mesin</option>
                            <option value="Teknik Informatika" class="dropdown-item form-control">Teknik Informatika</option>
                            <option value="Administrasi Bisnis Internasional" class="dropdown-item form-control">Administrasi Bisnis Internasional</option> -->
                        </select>
                    </div>

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="text">Nama Pengembali</label>
                        <input value="" type="text" name="nama_pengembali" class="form-control" id="email" required>
                    </div> -->

                    <div class="form-group fs-5 pb-4">
                        <label for="jenis_barang">NIM Pengembali</label>
                        <input value="" type="text" name="nim_pengembali" class="form-control" id="nim_pengembali" required>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="kondisi_barang">Prodi Pengembali</label>
                        <input value="" type="text" name="prodi_pengembali" class="form-control" id="prodi_pengembali" required>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="jumlah_barang">Kelas Pengembali</label>
                        <input value="" type="text" name="kelas_pengembali" class="form-control" id="kelas_pengembali" required>
                    </div>

                    <div class="form-group fs-5 pb-4 d-none">
                        <label for="lokasi_barang">Id Mahasiswa Pengembali</label>
                        <input value="" type="password" name="id_mahasiswa_pengembali" class="form-control" id="id_mahasiswa_pengembali" required>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="lokasi_barang">Jumlah Barang Dikembalikan</label>
                        <input value="" type="number" name="jumlah_pengembalian" class="form-control" id="jumlah_pengembalian" required>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg">Tambah Pengembalian</button>
                    <a class="btn btn-success" href="<?= base_url() ?>admin/transaksi_peminjaman">Kembali</a>

                </form>
            </div>

            <div class="col col-lg-6">

                <h3>Data Barang</h3>
                <form>
                    <div class="form-group fs-5 pb-4">
                        <label for="nama_barang">Nama Barang</label>
                        <input value="<?= $dataDetail[0]->nama_barang ?>" type="text" name="nama_barang" class="form-control" id="nama_barang" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="jenis_barang">Jenis Barang</label>
                        <input value="<?= $dataDetail[0]->jenis_barang?>" type="text" name="jenis_barang" class="form-control" id="jenis_barang" required readonly>
                    </div>

                    <div class="form-group fs-5 pb-4">
                        <label for="jumlah_barang">Jumlah Peminjaman</label>
                        <input value="<?= $dataDetail[0]->jumlah_peminjaman ?>" type="number" name="jumlah_barang" class="form-control" id="jumlah_barang" required readonly>
                    </div>

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="kondisi_barang">Kondisi Barang</label>
                        <input value="kondisi barang" type="text" name="kondisi_barang" class="form-control" id="kondisi_barang" required readonly>
                    </div> -->

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="lokasi_barang">Lokasi Barang</label>
                        <input value="lokasi barang" type="text" name="lokasi_barang" class="form-control" id="lokasi_barang" required readonly>
                    </div> -->

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="pengguna_barang">Pengguna Barang</label>
                        <input value="pengguna barang" type="text" name="pengguna_barang" class="form-control" id="pengguna_barang" required readonly>
                    </div> -->

                    <div class="form-group fs-5 pb-4">
                        <label for="merk_barang">Merk Barang</label>
                        <input value="<?= $dataDetail[0]->merk_barang ?>" type="text" name="merk_barang" class="form-control" id="merk_barang" required readonly>
                    </div>

                    <!-- <div class="form-group fs-5 pb-4">
                        <label for="kategori_barang">Kategori Barang</label>
                        <input value="kategori barang" type="text" name="kategori_barang" class="form-control" id="kategori_barang" required readonly>
                    </div> -->

                </form><!--End Data Barang -->

            </div>

        </div>
    </div>

</main><!-- End #main -->