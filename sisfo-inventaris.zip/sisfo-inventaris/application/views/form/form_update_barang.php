<main id="main" class="main">

    <h1>Update Data Barang</h1>
    <!-- <h3>Masukan Data Peminjaman Barang</h3> -->

    <div class="row">
        <div class="col col-lg-8">

            <form action="<?= base_url() ?>admin/update_data/<?= $dataDetail[0]->id_barang ?>" method="POST">

                <div class="form-group fs-5 pb-4">
                    <label for="text">Nama Barang</label>
                    <input value="<?= $dataDetail[0]->nama_barang ?>" type="text" name="nama_barang" class="form-control" id="email" required>
                </div>

                <div class="form-group fs-5 pb-4">
                    <select class="dropdown fs-5 w-100" id="jenisbarang" name="jenis_barang" required>
                        <option disabled>Jenis Barang</option>

                        <option <?php if ($dataDetail[0]->jenis_barang == "Barang Microcontroller") echo "selected"; ?> id="opsi" value="Barang Microcontroller" class="dropdown-item form-control">Barang Microcontroller</option>
                        <option <?php if ($dataDetail[0]->jenis_barang == "Barang Praktek Technical Support") echo ' selected="selected"'; ?>id="opsi" value="Barang Praktek Technical Support" class="dropdown-item form-control">Barang Praktek Technical Support</option>
                        <option <?php if ($dataDetail[0]->jenis_barang == "Perangkat Jaringan") echo ' selected="selected"'; ?>id="opsi" value="Perangkat Jaringan" class="dropdown-item form-control">Perangkat Jaringan</option>
                    </select>
                </div>
                <!-- Jenis Barang End -->

                <div class="form-group fs-5 pb-4">
                    <label for="jumlah_barang">Jumlah Barang</label>
                    <input value="<?= $dataDetail[0]->jumlah_barang ?>" type="number" name="jumlah_barang" class="form-control" id="jumlah_barang" required>
                </div>

                <div class="form-group fs-5 pb-4">
                    <select class="dropdown fs-5 w-100" id="jenisbarang" name="kondisi_barang" required>
                        <option disabled>Kondisi Barang</option>
                        <option value="Baik" class="dropdown-item form-control" <?php if ($dataDetail[0]->kondisi_barang == "Baik") {
                                                                                    echo "Selected";
                                                                                } ?>>Baik</option>
                        <option value="Kurang Baik" class="dropdown-item form-control" <?php if ($dataDetail[0]->kondisi_barang == "Kurang Baik") {
                                                                                            echo "Selected";
                                                                                        } ?>>Kurang Baik</option>
                        <option value="Rusak" class="dropdown-item form-control" <?php if ($dataDetail[0]->kondisi_barang == "Baik") {
                                                                                        echo "Rusak";
                                                                                    } ?>>Rusak</option>
                    </select>
                </div><!-- End Kondisi Barang -->

                <div class="form-group fs-5 pb-4">
                    <label for="lokasi_barang">Lokasi Barang</label>
                    <input value="<?= $dataDetail[0]->lokasi_barang ?>" type="text" name="lokasi_barang" class="form-control" id="lokasi_barang" required>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="pengguna_barang">Pengguna Barang</label>
                    <input value="<?= $dataDetail[0]->pengguna_barang ?>" type="text" name="pengguna_barang" class="form-control" id="pengguna_barang" required>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="merk_barang">Merk Barang</label>
                    <input value="<?= $dataDetail[0]->merk_barang ?>" type="text" name="merk_barang" class="form-control" id="merk_barang" required>
                </div>

                <div class="form-group fs-5 pb-4">
                    <label for="kategori_barang">Kategori Barang</label>
                    <input value="<?= $dataDetail[0]->kategori_barang ?>" type="text" name="kategori_barang" class="form-control" id="kategori_barang" required>
                </div>

                <button href="#" class="btn btn-success btn-lg">Ubah Data</button>
                <a href="<?= base_url() ?>admin" class="btn btn-danger btn-lg">Kembali</a>

            </form>

        </div>
    </div>

</main><!-- End #main -->