<main id="main" class="main">

    <h1>Tambah Data Peminjaman</h1>
    <!-- <h3>Masukan Data Peminjaman Barang</h3> -->

    <div class="row">
        <div class="col col-lg-8">

            <form action="<?= base_url() ?>admin/inputData" method="POST">

                <div class="form-group fs-5 pb-4">
                    <!-- <label for="text">Nama Barang</label> -->
                    <input placeholder="Nama Barang" type="text" name="nama_barang" class="form-control" id="email" required>
                </div>

                <div class="form-group fs-5 pb-4">
                    <select class="dropdown fs-5 w-100" id="jenisbarang" name="jenis_barang" required>
                        <option disabled selected>Jenis Barang</option>
                        <option value="Barang Microcontroller" class="dropdown-item form-control">Barang Microcontroller</option>
                        <option value="Barang Praktek Technical Support" class="dropdown-item form-control">Barang Praktek Technical Support</option>
                        <option value="Perangkat Jaringan" class="dropdown-item form-control">Perangkat Jaringan</option>
                    </select>
                </div>
                <!-- Jenis Barang End -->

                <!-- <div class="form-group fs-5 pb-4">
                    <label for="jenis_barang">Jenis Barang</label>
                    <input type="text" name="jenis_barang" class="form-control" id="jenis_barang" required>
                </div> -->

                <div class="form-group fs-5 pb-4">
                    <!-- <label for="jumlah_barang">Jumlah Barang</label> -->
                    <input placeholder="Jumlah Barang" type="number" name="jumlah_barang" class="form-control" id="jumlah_barang" required>
                </div>

                <div class="form-group fs-5 pb-4">
                    <select class="dropdown fs-5 w-100" id="jenisbarang" name="kondisi_barang" required>
                        <option disabled selected>Kondisi Barang</option>
                        <option value="Baik" class="dropdown-item form-control">Baik</option>
                        <option value="Kurang Baik" class="dropdown-item form-control">Kurang Baik</option>
                        <option value="Rusak" class="dropdown-item form-control">Rusak</option>
                    </select>
                </div><!-- End Kondisi Barang -->

                <div class="form-group fs-5 pb-4">
                    <select class="dropdown fs-5 w-100" id="jenisbarang" name="lokasi_barang" required>
                        <option value="" disabled selected>Lokasi Barang</option>
                        <option value="Ruang ICT" class="dropdown-item form-control">Ruang ICT</option>
                        <option value="Ruang Microcontroller" class="dropdown-item form-control">Ruang Microcontroller</option>
                        <option value="Ruang Lab Sistem Informasi" class="dropdown-item form-control">Ruang Lab Sistem Informasi</option>
                        <option value="Ruang Lab Komputer Dasar" class="dropdown-item form-control">Ruang Lab Komputer Dasar</option>
                    </select>
                </div>
                <!-- End Jenis Barang -->

                <div class="form-group fs-5 pb-4">
                    <!-- <label for="pengguna_barang">Pengguna Barang</label> -->
                    <input placeholder="Pengguna Barang" type="text" name="pengguna_barang" class="form-control" id="pengguna_barang" required>
                </div>

                <div class="form-group fs-5 pb-4">
                    <!-- <label for="merk_barang">Merk Barang</label> -->
                    <input placeholder="Merk Barang" type="text" name="merk_barang" class="form-control" id="merk_barang" required>
                </div>

                <div class="form-group fs-5 pb-4">
                    <!-- <label for="kategori_barang">Kategori Barang</label> -->
                    <input placeholder="Kategori Barang" type="text" name="kategori_barang" class="form-control" id="kategori_barang" required>
                </div>
                <button class="btn btn-primary btn-lg">Tambah Data</button>
            </form>


        </div>
    </div>

</main><!-- End #main -->