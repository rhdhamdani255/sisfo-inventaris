<?php

class Admin_model extends CI_Model
{

    public function getData($id = 0)
    {

        if ($id > 0) {
            $result = $this->db->get_where('tb_data_master', array('id_barang' => $id));

            return $result->result();
        }
        $result = $this->db->get('tb_data_master');
        return $result->result();
    }

    public function get_data_tb_peminjaman()
    {
        return $this->db->get("tb_peminjaman");
    }

    public function insertData($data = null)
    {
        if (is_null($data)) return;
        $resultQuery = $this->db->insert('tb_data_master', $data);
        return $resultQuery;
    }

    public function deleteData($id = 0)
    {
        $this->db->where("id_barang", $id);
        return $this->db->delete("tb_data_master");
    }

    public function update_data($id = 0, $data = null)
    {
        if ($id <= 0 || is_null($data)) return;
        return $this->db->update('tb_data_master', $data, array('id_barang' => $id));
    }

    public function insert_data_peminjaman($data = null)
    {
        if ($data == null) return;
        $this->db->trans_begin();
        //insert tb peminjaman
        $this->db->insert('tb_peminjaman', $data);
        //update tb_data_master kolom jumlah peminjaman
        $this->db->set('jumlah_barang', "jumlah_barang-{$data['jumlah_peminjaman']}", FALSE);
        $this->db->where('id_barang', $data['id_barang']);
        $this->db->update('tb_data_master');
        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
            $this->db->trans_rollback();
            return false;
        }else {
            $this->db->trans_commit();
            return true;
        }
    }

    public function get_data_transaksi_peminjaman()
    {
        $this->db->select('tb_peminjaman.jumlah_peminjaman, tb_peminjaman.id_peminjaman, tb_peminjaman.tanggal_peminjaman, 
        tb_peminjaman.status, tb_mahasiswa.nama, tb_mahasiswa.nim, tb_kelas.nama_kelas, tb_prodi.nama_prodi, tb_data_master.nama_barang');
        $this->db->from('tb_peminjaman');
        $this->db->join('tb_data_master', 'tb_peminjaman.id_barang = tb_data_master.id_barang');
        $this->db->join('tb_mahasiswa', 'tb_mahasiswa.id_mhs = tb_peminjaman.id_mahasiswa_peminjam');
        $this->db->join('tb_kelas', 'tb_mahasiswa.kelas_id = tb_kelas.id_kelas');
        $this->db->join('tb_prodi', 'tb_mahasiswa.prodi_id = tb_prodi.kode_prodi');
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_data_transaksi_pengembalian()
    {
        $this->db->select('tb_pengembalian.jumlah_pengembalian, tb_pengembalian.tanggal_pengembalian, tb_data_master.nama_barang, 
        tb_prodi.nama_prodi, tb_mahasiswa.nama, tb_mahasiswa.nim');
        $this->db->from('tb_pengembalian');
        $this->db->join('tb_peminjaman', 'tb_peminjaman.id_peminjaman = tb_pengembalian.id_peminjaman', 'left')
        ->join('tb_data_master', 'tb_pengembalian.id_barang = tb_data_master.id_barang')
        ->join('tb_mahasiswa', 'tb_pengembalian.id_mahasiswa_pengembali = tb_mahasiswa.id_mhs')
        ->join('tb_prodi', 'tb_mahasiswa.prodi_id = tb_prodi.kode_prodi');
        $query = $this->db->get();
        return $query->result();
    }

    public function get_data_form_pengembalian($id_peminjaman = 0)
    {
        $this->db->select('tb_peminjaman.jumlah_peminjaman, tb_kelas.nama_kelas, tb_peminjaman.id_barang, tb_peminjaman.id_peminjaman, tb_peminjaman.tanggal_peminjaman,  tb_peminjaman.id_mahasiswa_peminjam , tb_mahasiswa.nama, tb_mahasiswa.nim,
         tb_data_master.nama_barang, tb_data_master.merk_barang, tb_data_master.jenis_barang, tb_prodi.nama_prodi');
        $this->db->from("tb_peminjaman");
        $this->db->where('id_peminjaman', $id_peminjaman);
        $this->db->join('tb_data_master', 'tb_data_master.id_barang = tb_peminjaman.id_barang');
        $this->db->join('tb_mahasiswa', 'tb_mahasiswa.id_mhs = tb_peminjaman.id_mahasiswa_peminjam');
        $this->db->join('tb_prodi', 'tb_mahasiswa.prodi_id = tb_prodi.kode_prodi');
        $this->db->join('tb_kelas', 'tb_mahasiswa.kelas_id = tb_kelas.id_kelas');
        $query = $this->db->get();
        return $query->result();
    }

    public function insert_data_pengembalian($data = null)
    {
        if (is_null($data)) return false;
      
        $this->db->trans_begin();
        //insert data ke tb_pengembalian
        $this->db->insert('tb_pengembalian', $data);

       // update tb_peminjaman
        $this->db->set('status', "Sudah Dikembalikan");
        $this->db->where('id_peminjaman', $data['id_peminjaman']);
        $this->db->update('tb_peminjaman');
    
        //update tb_data_master
        $this->db->set('jumlah_barang', "jumlah_barang+{$data['jumlah_pengembalian']}", FALSE);
        $this->db->where('id_barang', $data['id_barang']);
        $this->db->update('tb_data_master');

        $this->db->trans_complete();

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
            return false;
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    public function get_history_transaksi()
    {
   
        $this->db->select("npem.nama AS nama_peminjam, npem.nim AS nim_peminjam, npeng.nama AS nama_pengembali,
         npeng.nim AS nim_pengembali, tb_data_master.nama_barang, tb_peminjaman.tanggal_peminjaman, 
         tb_pengembalian.tanggal_pengembalian, tb_peminjaman.jumlah_peminjaman, 
         tb_pengembalian.jumlah_pengembalian");

        $this->db->from('tb_mahasiswa AS npem');
        $this->db->join('tb_peminjaman', 'tb_peminjaman.id_mahasiswa_peminjam = npem.id_mhs');

        $this->db->join('tb_pengembalian', 'tb_pengembalian.id_peminjaman = tb_peminjaman.id_peminjaman');
        $this->db->join('tb_mahasiswa AS npeng', 'tb_pengembalian.id_mahasiswa_pengembali = npeng.id_mhs');
        $this->db->join('tb_data_master', 'tb_pengembalian.id_barang = tb_data_master.id_barang');
        
        $result_data = $this->db->get();
        if ($result_data == null){
            return false;
        }else {
            return $result_data->result();
        }
    }

    public function update_last_login_user($id_user = 0)
    {
        date_default_timezone_set("Asia/Jakarta");
        $this->db->set('terakhir_login', date('l d-F-Y H:i:s'));
        $this->db->where('id_admin', $id_user);
        return $this->db->update('tb_users');
        
    }

    public function get_mahasiswa_name(){

        $this->db->select('nama');
        $this->db->order_by('nama', 'asc');
        $this->db->from('tb_mahasiswa');
        $result = $this->db->get();
        return $result->result();
        
    }

    public function get_data_peminjam($nama){

        if ($nama == null){
            return false;
            // $this->db->select('tb_mahasiswa.nim, tb_mahasiswa.id_mhs, tb_prodi.nama_prodi, tb_kelas.nama_kelas');
            // $this->db->from('tb_mahasiswa');
            // $this->db->join('tb_kelas', 'tb_mahasiswa.kelas_id=tb_kelas.id_kelas', 'inner join');
            // $this->db->join('tb_prodi', 'tb_mahasiswa.prodi_id=tb_prodi.kode_prodi');
            // $result = $this->db->get();
            // return $result->result();
        }

        $this->db->select('tb_mahasiswa.nim,  tb_mahasiswa.id_mhs, tb_prodi.nama_prodi, tb_kelas.nama_kelas');
        $this->db->from('tb_mahasiswa');
        $this->db->where('nama', $nama);
        $this->db->join('tb_kelas', 'tb_mahasiswa.kelas_id=tb_kelas.id_kelas', 'inner join');
        $this->db->join('tb_prodi', 'tb_mahasiswa.prodi_id=tb_prodi.kode_prodi');
        
        $result = $this->db->get();
        return $result->result();
        
    }
 }
