$(document).ready(function () { 

    $("#tablepeminjaman").DataTable({
		ajax: {
			url: "http://localhost/sisfo-inventaris/admin/get_data_table_peminjaman",
			type: "GET",
			dataSrc : "data"
		},

		scrollX : true,
		columns: [
			{ data: "no" },
			{ data: "nama_barang" },
			{ data: "jenis_barang" },
			{ data: "jumlah_barang" },
			{ data: "kondisi_barang" },
			{ data: "lokasi_barang" },
			{ data: "pengguna_barang" },
			{ data: "merk_barang" },
			{ data: "kategori_barang" },
		],

		columnDefs :[{
			targets : 9,
			data : "id_barang",
			render : function(data){
				return '<a class="btn btn-success me-1" type="submit" href="'+baseurl+'admin/form_peminjaman/'+data+'">Pinjam</a>';
			}
		}]

	});

    $("#tabletransaksipeminjaman").DataTable({
		ajax: {
			url: "http://localhost/sisfo-inventaris/admin/get_data_transaksi_peminjaman_as_json",
			type: "GET",
			dataSrc : "data"
		},

		scrollX : true,
		scrollY : true,

		columns: [
			{ data: "no" },
			{ data: "nama" },
			{ data: "nim" },
			{ data: "nama_barang" },
			{ data: "nama_prodi" },
			{ data: "nama_kelas" },
			{ data: "nama_barang" },
			{ data: "jumlah_peminjaman" },
			{ data: "status" },
			{ data: "tanggal_peminjaman" }
		],

		columnDefs : [{
			targets : 9,
			data : "id_peminjaman",
			data : "status",
			render : function(data, type, row){
				html = "";

				if (row.status == "Sedang Dipinjam"){
					html = '<a class="btn btn-warning btn-sm" type="submit" href="'+baseurl+'admin/form_pengembalian/'+row.id_peminjaman+'">Pengembalian</a>'
				}else {
					html = '<a class="btn btn-success btn-sm">Sudah Dikembalikan</a>';
				}
				return html;
			}
		}]
	});


	$("#table_histori_transaksi").DataTable({
		ajax: {
			url: "http://localhost/sisfo-inventaris/admin/get_histori_transaksi_as_json",
			type: "GET",
			dataSrc : "data"
		},
		scrollX : true,
		scrollY : true,
		columns: [
			{ data: "no" },
			{ data: "nama_peminjam" },
			{ data: "nim_peminjam" },
			{ data: "nama_barang" },
			{ data: "jumlah_peminjaman" },
			{ data: "tanggal_peminjaman" },
			{ data: "nama_pengembali" },
			{ data: "nim_pengembali" },
			{ data: "nama_barang" },
			{ data: "jumlah_pengembalian" },
			{ data: "tanggal_pengembalian" }
		]

	});

	$("#tabledashboard").DataTable({
		ajax: {
			url: "http://localhost/sisfo-inventaris/admin/get_data",
			type: "GET",
			dataSrc : "data"
		},
		scrollX : true,
		columns: [
			{ data: "no" },
			{ data: "nama_barang" },
			{ data: "jenis_barang" },
			{ data: "jumlah_barang" },
			{ data: "kondisi_barang" },
			{ data: "lokasi_barang" },
			{ data: "pengguna_barang" },
			{ data: "merk_barang" },
			{ data: "kategori_barang" },
		
		],

	});

	$("#tabledatamaster").DataTable({
	
		ajax: {
			url: "http://localhost/sisfo-inventaris/admin/get_data",
			type: "GET",
			dataSrc : "data"
		},
	scrollX : true,
	scrollY : true,
		columns: [
			{ data: "no" },
			{ data: "nama_barang" },
			{ data: "jenis_barang" },
			{ data: "jumlah_barang" },
			{ data: "kondisi_barang" },
			{ data: "lokasi_barang" },
			{ data: "pengguna_barang" },
			{ data: "merk_barang" },
			{ data: "kategori_barang" },
		
		],

		columnDefs : [{
			targets : 9,
			data : "id_barang", 
			render : function (data) {
				return '<a class="btn btn-success w-100" type="submit" href="'+ baseurl +'admin/detail/'+data+'">Detail</a>' + 
				'<a class="btn btn-warning w-100" type="submit" href="'+ baseurl +'admin/update/'+data+'">Ubah</a>';
			  }
		}],
	});

	$("#tabletransaksipengembalian").DataTable({
		ajax : {

			url: "http://localhost/sisfo-inventaris/admin/get_data_transaksi_pengembalian_as_json",
			type: "GET",
			dataSrc : "data"
		},

		scrollX : true,
		scrollY : true,
		columns: [
			{ data: "no" },
			{ data: "nama" },
			{ data: "nim" },
			{ data: "nama_prodi" },
			{ data: "nama_barang" },
			{ data: "jumlah_pengembalian" },
			{ data: "tanggal_pengembalian" },
		],
	});

	get_nama_mahasiswa();
	seePassword();

    });

	function get_nama_mahasiswa(){
		const nama_peminjam = $("#nama_peminjam");
		const nama_pengembali = $("#nama_pengembali");
		namaHtml = "";
		const ajax = new XMLHttpRequest();
		ajax.onload = function(){
			const data = JSON.parse(ajax.responseText);
			namaHtml = "<option disabled selected>Nama Peminjam</option>"
			for(const key in data){
				namaHtml +=  "<option value='"+ data[key].nama +"' class='dropdown-item form-control'>" + data[key].nama + "</option>";
			}
			
			nama_peminjam.html(namaHtml);
			nama_pengembali.html(namaHtml);
		}

		ajax.open("GET", "http://localhost/sisfo-inventaris/admin/get_nama_mahasiswa");
		ajax.send();
	}

	function setSamePerson (nama, nim, prodi, kelas, jumlah, id_mahasiswa_pengembali) 
	{
		document.getElementById('nama_peminjam').value = nama;
		document.getElementById('nim_pengembali').value = nim;
		document.getElementById('prodi_pengembali').value = prodi;
		document.getElementById('kelas_pengembali').value = kelas;
		document.getElementById('id_mahasiswa_pengembali').value = id_mahasiswa_pengembali;
		document.getElementById('jumlah_pengembalian').value = jumlah;
	}

	function setDataPeminjam(form) 
	{
		if (form == 'pengembalian'){
			$.ajax({
				type : "GET",
				url : "http://localhost/sisfo-inventaris/admin/get_data_peminjam?nama="+document.getElementById('nama_pengembali').value,
				dataType : "json",
				success : function(response){
					if (response.status == 404) {
						alert("Data tidak ditemukan!/n Kode : " + response.status)
						return;
					}
					for (key in response){
						document.getElementById('nim_pengembali').value = response.data[0].nim;
						document.getElementById('prodi_pengembali').value = response.data[0].nama_prodi;
						document.getElementById('kelas_pengembali').value = response.data[0].nama_kelas;
						document.getElementById('id_mahasiswa_pengembali').value = response.data[0].id_mhs;
					}
				} 
			})
			return;
		}
		
		$.ajax({
			type : "GET",
			url : "http://localhost/sisfo-inventaris/admin/get_data_peminjam?nama="+document.getElementById('nama_peminjam').value,
			dataType : "json",
			success : function(response){
			
				if (response.status == 404) {
					alert("Data tidak ditemukan!/n Kode : " + response.status)
					return;
				}
				for (key in response.data){
				
					console.log("Key : " + key)
					document.getElementById('nim_peminjam').value = response.data[key]['nim'];
					document.getElementById('prodi_peminjam').value = response.data[key]['nama_prodi'];
					document.getElementById('kelas_peminjam').value = response.data[key]['nama_kelas'];
					document.getElementById('id_mahasiswa').value = response.data[key]['id_mhs'];
				}

			}
		})
	}

	function seePassword(){

		if ($('#password').attr("type") == "password") {
		  $('#password').attr("type", "text");
		} else {
		  $('#password').attr("type", "password");
		}
		
	}