-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2023 at 05:32 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventaris_polkam`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_data_master`
--

CREATE TABLE `tb_data_master` (
  `id_barang` int(50) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jenis_barang` enum('Barang Microcontroller','Barang Prakter Technical Support','Perangkat Jaringan','') NOT NULL,
  `jumlah_barang` int(11) UNSIGNED NOT NULL,
  `kondisi_barang` enum('Baik','Kurang Baik','Rusak','') NOT NULL,
  `lokasi_barang` enum('Ruang ICT','Ruang Microcontroller','Ruang Lab Sistem Informasi','Ruang Lab Komputer Dasar') NOT NULL,
  `pengguna_barang` varchar(100) NOT NULL,
  `merk_barang` varchar(100) NOT NULL,
  `kategori_barang` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_data_master`
--

INSERT INTO `tb_data_master` (`id_barang`, `nama_barang`, `jenis_barang`, `jumlah_barang`, `kondisi_barang`, `lokasi_barang`, `pengguna_barang`, `merk_barang`, `kategori_barang`) VALUES
(1, 'Kabel HDMI', 'Barang Microcontroller', 4, 'Baik', 'Ruang ICT', 'Mahasiswa', 'Asus', 'Kabel'),
(21, 'Keyboard', 'Barang Microcontroller', 2, 'Baik', 'Ruang Microcontroller', 'Mahasiswa', 'Jeytech', 'Komponen Komputer'),
(22, 'Printer', 'Barang Microcontroller', 3, 'Baik', 'Ruang ICT', 'Mahasiswa', 'HP', 'Komponen Komputer'),
(25, 'Mouse', 'Barang Prakter Technical Support', 3, 'Baik', 'Ruang Lab Komputer Dasar', 'Mahasiswa', 'Dell', 'Komponen Komputer');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kelas`
--

CREATE TABLE `tb_kelas` (
  `id_kelas` int(11) NOT NULL,
  `nama_kelas` varchar(30) NOT NULL,
  `jurusan_id` int(11) NOT NULL,
  `dosen_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tb_kelas`
--

INSERT INTO `tb_kelas` (`id_kelas`, `nama_kelas`, `jurusan_id`, `dosen_id`) VALUES
(1, 'PPM 1A 2019', 12, 16),
(2, 'PPM 1B 2019', 12, 12),
(3, 'TPS 1A 2019', 11, 10),
(4, 'TPS 1B 2019', 11, 9),
(5, 'TIF 1A 2019', 13, 1),
(6, 'TIF 1B 2019', 13, 2),
(7, 'TIF 2 ', 13, 1),
(8, 'PPM 2018 ', 12, 13),
(9, 'TPS 2018 ', 11, 11),
(10, 'ABI 1', 14, 18),
(11, 'ABI 2 2019', 14, 17),
(12, 'TPS A 2020 ', 11, 7),
(13, 'TPS B 2020', 11, 6),
(14, 'PPM A 2020', 12, 20),
(15, 'PPM B 2020', 12, 14),
(16, 'TIF A 2020', 13, 19),
(17, 'TIF B 2020', 13, 5),
(18, 'ABI 2020', 14, 21),
(19, 'TPS A 2021', 11, 22),
(20, 'TPS B 2021', 11, 11),
(21, 'PPM A 2021', 12, 23),
(22, 'PPM B 2021', 12, 13),
(23, 'TIF A 2021', 13, 2),
(24, 'TIF B 2021', 13, 1),
(25, 'ABI 2021', 14, 24),
(26, 'TPS A 2022', 11, 10),
(27, 'TPS B 2022', 11, 9),
(28, 'PPM A 2022', 12, 16),
(29, 'PPM B 2022', 12, 12),
(30, 'TIF A 2022', 13, 30),
(31, 'TIF B 2022', 13, 29),
(32, 'ABI 2022', 14, 18),
(33, 'TPKS 2022', 121, 33);

-- --------------------------------------------------------

--
-- Table structure for table `tb_mahasiswa`
--

CREATE TABLE `tb_mahasiswa` (
  `id_mhs` int(10) NOT NULL,
  `nim` varchar(25) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `prodi_id` int(5) NOT NULL,
  `semester_id` int(5) NOT NULL,
  `jenis_k` varchar(25) NOT NULL,
  `kelas_id` int(5) DEFAULT NULL,
  `status_study` enum('Lulus','Study') DEFAULT NULL,
  `jenjang_study` enum('D2','D3','D4') DEFAULT NULL,
  `semester_awal` varchar(45) DEFAULT NULL,
  `foto` varchar(145) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tb_mahasiswa`
--

INSERT INTO `tb_mahasiswa` (`id_mhs`, `nim`, `nama`, `email`, `prodi_id`, `semester_id`, `jenis_k`, `kelas_id`, `status_study`, `jenjang_study`, `semester_awal`, `foto`) VALUES
(1, '201811001', 'Nesmi Arianti Hasibuana', 'nesmi2018.tps@poltek-kampar.ac.id', 11, 6, 'P', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(2, '201811002', 'Sugiarto', 'sugiarto2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(3, '201811003', 'Sesti Yopita', 'sesti2018.tps@poltek-kampar.ac.id', 11, 6, 'P', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(4, '201811004', 'Alnando Nikolas Sagala', 'alnando2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(5, '201811005', 'Fitri Hidayani', 'fitrihidayani2018.tps@poltek-kampar.ac.id', 11, 6, 'P', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(6, '201811006', 'Herliana Putri', 'herliana2018.tps@poltek-kampar.ac.id', 11, 6, 'P', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(7, '201811007', 'Muhammad Ahsan Jihadan', 'muhammadahsan2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(8, '201811009', 'Tedja Hadi Pratama', 'tedja2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(9, '201811010', 'Rio ibnu ari febrianta', 'rio2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(10, '201811011', 'Nur Hasmi', 'nur2018.tps@poltek-kampar.ac.id', 11, 6, 'P', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(11, '201811012', 'Andi Saputra Harahap', 'andi2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(12, '201811013', 'Alfitrah Mulia Insani', 'alfitrah2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(13, '201811014', 'Tri Apri Aldi', 'tri2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(14, '201811015', 'Zainur Khotib', 'zainur2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(15, '201811016', 'Muhammad alKausar', 'muhammad2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(16, '201811017', 'Risma Wati', 'risma2018.tps@poltek-kampar.ac.id', 11, 6, 'P', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(17, '201811018', 'Fazri', 'fazri2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(18, '201811019', 'Rezky Wahyu Saputra', 'rezky2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(19, '201811020', 'Tifanny Wulandari', 'tifanny2018.tps@poltek-kampar.ac.id', 11, 6, 'P', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(20, '201811021', 'Sri Susanti', 'sri2018.tps@poltek-kampar.ac.id', 11, 6, 'P', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(21, '201811022', 'Nadya Elfitri', 'nadya2018.tps@poltek-kampar.ac.id', 11, 6, 'P', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(22, '201811023', 'Diva Yogi Husada', 'diva2018.tps@poltek-kampar.ac.id', 11, 6, 'L', 9, 'Lulus', 'D3', '2018 Ganjil', NULL),
(23, '201812001', 'Arifin Ahmad', 'arifin2018.ppm@poltek-kampar.ac.id', 12, 6, 'L', 8, 'Lulus', 'D3', '2018 Ganjil', NULL),
(24, '201812002', 'Wildan Akromi', 'wildan2018.ppm@poltek-kampar.ac.id', 12, 6, 'L', 8, 'Lulus', 'D3', '2018 Ganjil', NULL),
(25, '201812003', 'Raull Vadhilla. D', 'raull2018.ppm@poltek-kampar.ac.id', 12, 6, 'L', 8, 'Lulus', 'D3', '2018 Ganjil', NULL),
(26, '201812004', 'M. Hafis Alfarido', 'hafis2018.ppm@poltek-kampar.ac.id', 12, 6, 'L', 8, 'Lulus', 'D3', '2018 Ganjil', NULL),
(27, '201812005', 'Sandi Setiawan', 'sandi2018.ppm@poltek-kampar.ac.id', 12, 6, 'L', 8, 'Lulus', 'D3', '2018 Ganjil', NULL),
(28, '201812006', 'Hardiyat Maulana', 'hardiyat2018.ppm@poltek-kampar.ac.id', 12, 6, 'L', 8, 'Lulus', 'D3', '2018 Ganjil', NULL),
(29, '201813001', 'Erma Diana', 'erma2018.tif@poltek-kampar.ac.id', 13, 6, 'P', 7, 'Lulus', 'D3', '2018 Ganjil', NULL),
(30, '201813002', 'Chandra Wardana', 'chandra2018.tif@poltek-kampar.ac.id', 13, 6, 'L', 7, 'Lulus', 'D3', '2018 Ganjil', NULL),
(31, '201813003', 'Putri Handa Yani', 'putri2018.tif@poltek-kampar.ac.id', 13, 6, 'P', 7, 'Lulus', 'D3', '2018 Ganjil', NULL),
(32, '201813004', 'Faridah Badriyyah', 'faridah2018.tif@poltek-kampar.ac.id', 13, 6, 'P', 7, 'Lulus', 'D3', '2018 Ganjil', NULL),
(33, '201813005', 'M. Diaz Rahmadi', 'diaz2018.tif@poltek-kampar.ac.id', 13, 6, 'L', 7, 'Lulus', 'D3', '2018 Ganjil', NULL),
(34, '201814001', 'Resis Marlita', 'resis2018.abi@poltek-kampar.ac.id', 14, 7, 'P', 10, 'Lulus', 'D3', '2018 Ganjil', NULL),
(35, '201814002', 'Fitria Melsi Wendra', 'fitria2018.abi@poltek-kampar.ac.id', 14, 8, 'P', 10, 'Lulus', 'D3', '2018 Ganjil', NULL),
(36, '201814003', 'Suci Rahayu', 'suci2018.abi@poltek-kampar.ac.id', 14, 8, 'P', 10, 'Lulus', 'D3', '2018 Ganjil', NULL),
(37, '201814004', 'Novita Sari', 'novita2018.abi@poltek-kampar.ac.id', 14, 8, 'P', 10, 'Lulus', 'D3', '2018 Ganjil', NULL),
(38, '201814006', 'Rani Slapangki', 'rani2018.abi@poltek-kampar.ac.id', 14, 8, 'P', 10, 'Lulus', 'D3', '2018 Ganjil', NULL),
(39, '201814007', 'Imelda', 'imelda2018.abi@poltek-kampar.ac.id', 14, 8, 'P', 10, 'Lulus', 'D3', '2018 Ganjil', NULL),
(40, '201911001', 'Hafizh Ash Shiddiq', 'hafizh2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(41, '201911002', 'Neti Nurzanah', 'neti2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(42, '201911003', 'Rahmatunnisa', 'rahma2019.tps@poltek-kampar.ac.id', 11, 7, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(43, '201911004', 'Elvira Deswati', 'elvira2019.tps@poltek-kampar.ac.id', 11, 7, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(44, '201911005', 'Rahmadia Futri', 'rahmadia2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(45, '201911006', 'Luthfiah Afifah Aprilia', 'luthfiah2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(46, '201911007', 'Ika Lestari', 'ika2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(47, '201911008', 'Ilham Saputra', 'ilham2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(48, '201911010', 'Puput Handriyani', 'puput2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(49, '201911011', 'Salsabila Kirani', 'salsabila2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(50, '201911013', 'Putri Jusumi Ayuni', 'putri2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(51, '201911014', 'Ahmad Ravy', 'ahmad2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(52, '201911015', 'Amiruddin P. Ismail', 'amiruddin2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(53, '201911016', 'Arga Ocsteven Simbolon', 'arga2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(54, '201911017', 'Ari Alpindo Ketaren', 'ari2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(55, '201911018', 'Bisma Setiawan', 'bisma2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(56, '201911019', 'Dandy Efendi', 'dandy2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(57, '201911020', 'Diana Novita Ketaren', 'diana2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(58, '201911021', 'Dimas Aditia Ningrat', 'dimas2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(59, '201911022', 'Fitra Panji Utomo Putra', 'fitra2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(60, '201911023', 'Indra Saut Hasoloan Siahaan', 'indra2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(61, '201911024', 'Jaser Mando P Sitompul', 'jaser2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(62, '201911025', 'Luhut Pandapotan Harahap', 'luhut2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(63, '201911026', 'Mardiansyah', 'mardi2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(64, '201911027', 'Maulana Nanda Mahedra', 'maulana2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(65, '201911028', 'Mhd. Ade Gilang Prayoga', 'mhd2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(66, '201911029', 'Muhamad Guspikar', 'muhammad2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(67, '201911030', 'Najmudin Al Hafizh', 'najmudin2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(68, '201911031', 'Okky Noverta', 'okky2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(69, '201911032', 'P. Darmawan Laoli', 'darmawan2019.tps@poltek-kampar.ac.id', 11, 7, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(70, '201911033', 'Rahmat Hidayat', 'rahmat2019.tps@poltek-kampar.ac.id', 11, 7, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(71, '201911034', 'Rangga Pujata Efendi', 'rangga2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(72, '201911035', 'Riano Firdaus', 'riano2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(73, '201911036', 'Siti Armila', 'siti2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(74, '201911037', 'Yohana Br Pasaribu', 'yohana2019.tps@poltek-kampar.ac.id', 11, 7, 'P', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(75, '201911038', 'Zaibatul Aslamiah', 'zaibatul2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(76, '201911039', 'Zaki Dwi Ihtada', 'zaki2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(77, '201911040', 'Zeki Ramanda', 'zeki2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(78, '201911041', 'Zul Indra Akbar', 'zul2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(79, '201911042', 'Melinda', 'melinda2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(80, '201911043', 'Fajar As Shidqi', 'fajar2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 4, 'Lulus', 'D3', '2019 Ganjil', NULL),
(81, '201911044', 'Arya Satya', 'arya2019.tps@poltek-kampar.ac.id', 11, 7, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(82, '201911045', 'Muhammad Guntur', 'guntur2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(83, '201911046', 'Siswantomi Sidabalok', 'siswan2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(84, '201911047', 'Supini Wati', 'supini2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(85, '201911048', 'Evi Miswanti', 'evi2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(86, '201911049', 'Muhammad Masrur Farhan', 'masrur2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(87, '201911050', 'Nurfazira', 'nurfa2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(88, '201911051', 'Putri Sukma Dani', 'sukma2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(89, '201911052', 'Muhammad Anjas Rafiqi', 'anjas2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(90, '201911053', 'Prama Jaya Harefa', 'prama2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(91, '201911054', 'Muhammad Mukhlis', 'mukhlis2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(92, '201911055', 'Muhammad Arif', 'arif2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(93, '201911056', 'Jonathan Donisius Hasugian', 'jonathan2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(94, '201911057', 'Wardatul Hayani', 'wirdatul2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(95, '201911058', 'Zidni Falah', 'zidni2019.tps@poltek-kampar.ac.id', 11, 6, 'L', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(96, '201911060', 'Elli M', 'elli2019.tps@poltek-kampar.ac.id', 11, 6, 'P', 3, 'Lulus', 'D3', '2019 Ganjil', NULL),
(97, '201912001', 'Riandi', 'riandi2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(98, '201912002', 'Nanang Mujahid', 'nanang2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(99, '201912003', 'M. Elga Syahputra', 'elga2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(100, '201912004', 'Sandi Eka Putra', 'sandi2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(101, '201912005', 'Anggi Prayoga Sundawa', 'anggi2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(102, '201912006', 'Pernando', 'pernando2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(103, '201912007', 'Andre Rivaldo', 'andre2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(104, '201912008', 'Syawal Aidil Fikri', 'syawal2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(105, '201912009', 'Abdul Roji Hasibuan', 'abdul2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(106, '201912010', 'Aditya Feri Ramadan', 'aditya2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(107, '201912011', 'Ahmad Rizal Siregar', 'ahmad2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(108, '201912012', 'Aprido Prayogi', 'aprido2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(109, '201912013', 'Ardi Ramadhan Asra', 'ardi2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(110, '201912014', 'David Harapan Siahaan', 'david2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(111, '201912015', 'Defri Ramadhan', 'defri2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(112, '201912016', 'Devi Agustiani', 'devi2019.ppm@poltek-kampar.ac.id', 12, 6, 'P', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(113, '201912017', 'Fahri Wahyudi', 'fahri2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(114, '201912018', 'Fajri Ashiddiqy', 'fajri2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(115, '201912019', 'Horyn Tria Pamiaro Purba', 'horyn2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(116, '201912020', 'Josua Rahmat Telaumbanua', 'josua2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(117, '201912021', 'Khairul Anwar', 'khairul2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(118, '201912022', 'Landong Sait Simatupang', 'landong2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(119, '201912023', 'Lusiana', 'lusiana2019.ppm@poltek-kampar.ac.id', 12, 6, 'P', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(120, '201912024', 'M. Rafi', 'rafi2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(121, '201912025', 'Mhd Febrian Fadilla', 'febrian2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(122, '201912026', 'Muammar Arif', 'muammar2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(123, '201912027', 'Muhammad Arzak', 'arzak2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(124, '201912028', 'Pandu Danang Sudiro', 'pandu2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(125, '201912029', 'Panjulia Sandi Parapat', 'panjulia2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(126, '201912030', 'Randi Rahman', 'randi2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(127, '201912031', 'Reqi Hendrima Gunawan', 'reqi2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(128, '201912032', 'Ridho Ramadhan', 'ridho2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(129, '201912033', 'Samuel Ferdinand Simanjuntak', 'samuel2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(130, '201912034', 'Sandi Niardiyanto', 'niardiyanto2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(131, '201912035', 'Setia Adi Wardana', 'setia2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(132, '201912036', 'Solihin', 'solihin2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(133, '201912037', 'Sutrisno', 'sutrisno2019.ppm@poltek-kampar.ac.id', 12, 7, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(134, '201912038', 'M. Maulia Faturrahman', 'maulia2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 2, 'Lulus', 'D3', '2019 Ganjil', NULL),
(135, '201912039', 'Insan Ma\'aruf', 'insan2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(136, '201912040', 'Khairul Mufti', 'mufti2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(137, '201912041', 'Muhammad Andre Majid', 'majid2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(138, '201912042', 'Eggy Dharmasyah', 'egy2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(139, '201912043', 'Rieke Cerlina Oktovia', 'rieke2019.ppm@poltek-kampar.ac.id', 12, 6, 'P', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(140, '201912044', 'Rico Gunawan', 'rico2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(141, '201912045', 'Mhd. Ikmal Firdausi', 'ikmal2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(142, '201912046', 'Husnul Fikri', 'husnul2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(143, '201912047', 'Hendri Saputra', 'hendri2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(144, '201912048', 'Dedi Irawan', 'dedi2019.ppm@poltek-kampar.ac.id', 12, 6, 'L', 1, 'Lulus', 'D3', '2019 Ganjil', NULL),
(145, '201913001', 'Khairunnisa\' ', 'khairunisa2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(146, '201913002', 'Rahmat Hamdani', 'rahmat2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(147, '201913003', 'Wirdatul Jannah', 'wirdatul2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(148, '201913004', 'Ilham Agusta', 'ilham2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(149, '201913005', 'Indah Aprilia', 'indah2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(150, '201913006', 'Adela Maharani', 'adela2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(151, '201913007', 'Fahri Irawan', 'fahri2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(152, '201913008', 'Fia Fabila', 'fia2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(153, '201913009', 'Zikri Armansyah', 'zikri2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(154, '201913010', 'Yudi Hamdi Utama', 'yudi2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(155, '201913011', 'Fauziah Efani', 'fauziah2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(156, '201913012', 'Fuji Sri Sasmita', 'fuji2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(157, '201913013', 'Dwi Putri Nilam Cayo', 'dwi2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(158, '201913014', 'Novi Wahyuni', 'novi2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(159, '201913015', 'Bartolomeus Dado Mangunsong', 'bartolomeus2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(160, '201913016', 'Dian Nanda Anggraini', 'dian2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(161, '201913017', 'Dicky Prima Azhari', 'dicky2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(162, '201913018', 'Doni Dwi Sparingga', 'doni2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(163, '201913019', 'Egi Saputra', 'egi2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(164, '201913020', 'Fadila Kurnia Sari', 'fadila2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(165, '201913021', 'Farhan Fauzan', 'farhan2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(166, '201913022', 'Fika Nuril Hamdiyah', 'fika2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(167, '201913023', 'Guntur', 'guntur2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(168, '201913024', 'Jamrudi Abdillah', 'jamrudi2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(169, '201913025', 'Kristian Laiya', 'kristian2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(170, '201913026', 'Lisa Afriani', 'lisa2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(171, '201913027', 'Lisa Febrianingsih', 'febrianingsih2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(172, '201913028', 'Melysa Anggita Rani', 'melysa2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(173, '201913029', 'Bira Robiansyah', 'bira2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(174, '201913030', 'Novri Ramadani', 'novri2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(175, '201913031', 'Nur Aida', 'nur2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(176, '201913032', 'Raya. S', 'raya2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(177, '201913033', 'Renaldy Darma', 'renaldy2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(178, '201913034', 'Rianto Naldi', 'rianto2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(179, '201913035', 'Ribut Wibowo Rahayu', 'ribut2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(180, '201913036', 'Rika Novita Sari', 'rika2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(181, '201913037', 'Rizky Putra Pratama', 'rizky2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(182, '201913038', 'Ari Dimas Susanto', 'ari2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(183, '201913039', 'Susriadi', 'susriadi2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(184, '201913040', 'Veronica Fitria Putri', 'vironica2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(185, '201913041', 'Busroh Nurcahyani Ahmad', 'busroh2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(186, '201913042', 'Srikandi Khairunnisa', 'srikandi2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(187, '201913043', 'Muhammad Iqbal', 'iqbal2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(188, '201913044', 'M. Nur Alim Ritonga', 'm2019.tif@poltek-kampar.ac.id', 13, 6, 'L', 6, 'Lulus', 'D3', '2019 Ganjil', NULL),
(189, '201913045', 'Winta Amalia Ayu', 'winta2019.tif@poltek-kampar.ac.id', 13, 6, 'P', 5, 'Lulus', 'D3', '2019 Ganjil', NULL),
(190, '201913046', 'Wahyu Septiansyah', 'wahyu2019.tif@poltek-kampar.ac.id', 13, 5, 'L', 5, 'Study', 'D3', '2020 Ganjil', NULL),
(191, '201914001', 'Yuli Rahmadani Harahap', 'yuli2019.abi@poltek-kampar.ac.id', 14, 7, 'P', 11, 'Study', 'D4', '2019 Ganjil', NULL),
(192, '201914002', 'Ulfa Nur Safitri', 'ulfa2019.abi@poltek-kampar.ac.id', 14, 6, 'P', 11, 'Study', 'D4', '2019 Ganjil', NULL),
(193, '201914003', 'Iis Pramita', 'iis2019.abi@poltek-kampar.ac.id', 14, 6, 'P', 11, 'Study', 'D4', '2019 Ganjil', NULL),
(194, '201914004', 'Mabrur', 'mabrur2019.abi@poltek-kampar.ac.id', 14, 6, 'L', 11, 'Study', 'D4', '2019 Ganjil', NULL),
(195, '201914005', 'Ratna', 'ratna2019.abi@poltek-kampar.ac.id', 14, 6, 'P', 11, 'Study', 'D4', '2019 Ganjil', NULL),
(196, '201914006', 'Salsa Firdaus Putri', 'salsa2019.abi@poltek-kampar.ac.id', 14, 6, 'P', 11, 'Study', 'D4', '2019 Ganjil', NULL),
(197, '202011001', 'Nanang', 'nanang@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(198, '202011002', 'Tutur Mulyawan Siregar', 'tuturMulyawan@poltek-kampar.ac.id', 11, 6, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(199, '202011003', 'Linsi Afriani', 'LinsiAfriani@poltek-kampar.ac.id', 11, 6, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(200, '202011004', 'Raofan', 'raofan@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(201, '202011005', 'Rindy Amelia Andiny', 'AmeliaAndiny@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(202, '202011006', 'Nia Kumala Sari', 'niakumalasari@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(203, '202011007', 'Yanti Lufitra Sari Sitorus ', 'LufitraSari@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(204, '202011008', 'Juni Pernando Lubis', 'junipernando@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(205, '202011009', 'Susilianti', 'susilianti@poltek-kampar.ac.id', 11, 6, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(206, '202011010', 'Nonong', 'nonong@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(207, '202011011', 'Aditya Kurniawan Ketaren', 'aditya@poltek-kampar.ac.id', 11, 6, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(208, '202011012', 'Ayu Windi Rahmayani', 'ayuwindi@poltek-kampar.ac.id', 11, 6, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(209, '202011013', 'Sutriyadi', 'sutriyadi@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(210, '202011014', 'Adi Putra', 'adiputra@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(211, '202011015', 'Andi Supri Tambunan', 'andisupri@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(212, '202011016', 'Asrul Rahmadi Harahap', 'AsrulRahmadi@poltek-kampar.ac.id', 11, 6, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(213, '202011017', 'Daniel Lumban Tungkup', 'daniel@poltek-kampar.ac.id', 11, 6, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(214, '202011018', 'Doni Oktosunario G', 'doniOktosunario@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(215, '202011019', 'Eky El Hamidy', 'ekyhamidy@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(216, '202011020', 'Fredy Sanjiwo', 'fredySanjiwo@poltek-kampar.ac.id', 11, 5, 'L', NULL, 'Study', 'D3', '2020 Ganjil', NULL),
(217, '202011021', 'Gabriel Aritonang', 'Aritonang@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(218, '202011022', 'Genta Ramadhan', 'genta@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(219, '202011023', 'Hari Ribowo', 'Haritps@poltek-kampar.ac.id', 11, 6, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(220, '202011024', 'Haris Ahmadi', 'harisahmadi@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(221, '202011025', 'Irwanda Lubis', 'irwanda@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(222, '202011026', 'Joel Fernando Purba', 'Fernando@poltek-kampar.ac.id', 11, 6, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(223, '202011027', 'John Roberto Saputra', 'Roberto@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(224, '202011028', 'M. Risky Suhartono', 'suhartono@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(225, '202011029', 'Muhammad Ihsan', 'muhammadihsan@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(226, '202011030', 'Muhammad Novriyardi', 'muhammadnovriyardi@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(227, '202011031', 'Raka Saltsabillah Pazal', 'raka@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(228, '202011032', 'Rido Ksatria Siburian', 'rido@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(229, '202011033', 'Rizki Ramadhan', 'rizkiRamadhan@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(230, '202011034', 'Sandika Apriando Halim', 'sandika@poltek-kampar.ac.id', 11, 6, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(231, '202011035', 'Suheri', 'suheri@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(232, '202011036', 'Tengku Fadlisyah', 'tengku@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(233, '202011037', 'Yogi Pangestu ', 'yogi@poltek-kampar.ac.id', 11, 7, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(234, '202011038', 'Yosua Elkius Nababan', 'yosua@poltek-kampar.ac.id', 11, 5, 'L', 13, 'Study', 'D3', '2020 Ganjil', NULL),
(235, '202011039', 'Agung Arif Zulfikar ', 'agungarif@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(236, '202011040', 'Faiz Zulqirom', 'faiz@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(237, '202011041', 'Fernandus', 'fernandus@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(238, '202011042', 'Herfi D. Windra', 'herfi@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(239, '202011043', 'Ikhlasul Amali', 'ikhlasul@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(240, '202011044', 'Johan Maryanto Sinaga', 'johan@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(241, '202011045', 'Muhammad Alam Saputra', 'muhammad@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(242, '202011046', 'Muhammad Kurniawan', 'muhammadkurniawan@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(243, '202011047', 'Muhammad Raihan Aditya', 'muhammadaditya@poltek-kampar.ac.id', 11, 7, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(244, '202011048', 'Reski Safda Putra', 'reski@poltek-kampar.ac.id', 11, 5, 'L', NULL, 'Study', 'D3', '2020 Ganjil', NULL),
(245, '202011049', 'Rizky Wahyu Parmohonan Lubis', 'rizkywahyu@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(246, '202011050', 'Salman Alfarisi', 'salman@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(247, '202011051', 'Wahyu Putra Pratama ', 'wahyu@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(248, '202011052', 'Wira Mandala Putra', 'wiramandala@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(249, '202011053', 'Yoga Daniel Pratama Sinaga', 'yogad@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(250, '202011054', 'Yuda Deva Gustiranda ', 'yuda@poltek-kampar.ac.id', 11, 5, 'L', 12, 'Study', 'D3', '2020 Ganjil', NULL),
(251, '202012001', 'Dimas Jhon Hendrawan', 'dimas@poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(252, '202012002', 'Dion Dwi Putra', 'dion@poltek-kampar.ac.id', 12, 6, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(253, '202012003', 'Dirju Ifangga', 'dirju@poltek-kampar.ac.id', 12, 6, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(254, '202012004', 'Agustina Hasibuan', 'agustina@poltek-kampar.ac.id', 12, 6, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(255, '202012005', 'Reziki Anugrah', 'reziki@poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(256, '202012006', 'Rizki Azizi', 'rizkiazizi@poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(257, '202012007', 'Arya Imansyah Ramaddan', 'arya@poltek-kampar.ac.id', 12, 6, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(258, '202012008', 'Novreza Andika', 'novreza@poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(259, '202012009', 'Putra Jaga Raga', 'putraJagaRaga@poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(260, '202012010', 'Muhammad Iqbal Ardiansyah', 'muhammadi@poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(261, '202012011', 'Dery Rahmadoni Saputra', 'deryRahmadoni@poltek-kampar.ac.id', 12, 6, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(262, '202012012', 'M. Iqbal Hambali', 'iqbal@poltek-kampar.ac.id', 12, 6, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(263, '202012013', 'Ngadiyanti', 'ngadiyanti@poltek-kampar.ac.id', 12, 6, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(264, '202012014', 'Rahmat', 'rahmat@poltek-kampar.ac.id', 12, 6, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(265, '202012015', 'Purdiantoro', 'purdiantoro@poltek-kampar.ac.id', 12, 6, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(266, '202012016', 'M. Albito Tarmizal', 'albito@poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(267, '202012017', 'Abdullah Safiih Harianja', 'abdullahSafiih@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(268, '202012018', 'Aldi DM', 'Aldippm@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(269, '202012019', 'Andika Fajar Syahputra', 'andikafajar@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(270, '202012020', 'Aril Buttuan', 'arilButtuan@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(271, '202012021', 'Arjun Wahyu Pratomo', 'arjunWahyu@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(272, '202012022', 'Diki Candra', 'dikicandra@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(273, '202012023', 'Fauzan Arif Desandro', 'fauzanarif@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(274, '202012024', 'Firman Tarigan', 'firmanTarigan@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(275, '202012025', 'Guruh Fajrin Nugroho', 'GuruhFajrin@poltek-kampar.ac.id', 12, 6, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(276, '202012026', 'Hamzah Jamaluddin', 'hamzahJamaluddin@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(277, '202012027', 'Jamaludin Arif', 'JamaludinArif@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(278, '202012028', 'Michael Yehezkiel', 'MichaelYehezkiel@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(279, '202012029', 'Muhamad Fadli', 'MuhamadFadli@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(280, '202012030', 'Muhammad Rama Wijaya', 'RamaWijaya@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(281, '202012031', 'Muhammad Rifki', 'MuhammadRifki@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(282, '202012032', 'Muhammad Zulkarnaen', 'MuhammadZulkarnaen@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(283, '202012033', 'Mukhlis Hidayanto', 'mukhlisHidayanto@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(284, '202012034', 'Nasri', 'nasrippm@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(285, '202012035', 'Pirmanto', 'pirmantoppm@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(286, '202012036', 'Reza Hasim Rabbani', 'RezaHasim@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(287, '202012037', 'Riski Lumban Tobing', 'RiskiLumban@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(288, '202012038', 'Risqi Maulana ', 'RisqiMaulana@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(289, '202012039', 'Riswandi', 'riswandippm@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(290, '202012040', 'Ryan Fajar Rifai', 'RyanFajar@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(291, '202012041', 'Wahyu Ramadhan Syahputra', 'WahyuRamadhan@poltek-kampar.ac.id', 12, 5, 'L', 15, 'Study', 'D3', '2020 Ganjil', NULL),
(292, '202012042', 'Ananda Yusuf Anshori', 'anandayusuf@poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(293, '202012043', 'Andi Maysah', 'andi@poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(294, '202013001', 'Ferdi Febrian', 'FerdiFebrian@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(295, '202013002', 'Bella Tri Febri', 'BellaTri@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(296, '202013003', 'Nurzakia Fadilah', 'nurzakia@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(297, '202013004', 'Abel Liana', 'AbelLiana@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(298, '202013005', 'Ferdi Rahmat', 'ferdirahmat@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(299, '202013006', 'Ratri Pramudita Ningsih', 'RatriPramudita@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(300, '202013007', 'Dimas Abimayu', 'dimasabimayu@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(301, '202013008', 'Novia Arfitri', 'NoviaArfitri@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(302, '202013009', 'Fitri Wahyuni', 'FitriWahyuni@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(303, '202013010', 'Jesika', 'jesikatif@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(304, '202013011', 'Rahmi', 'rahmitif@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(305, '202013012', 'Muhammad Fauzan', 'MuhammadFauzan@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(306, '202013013', 'Selfia Carolin Pasaribu', 'SelfiaCarolin@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(307, '202013014', 'Hairul Rambe', 'hairulRambe@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(308, '202013015', 'Gio Damarzuki', 'GioDamarzuki@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(309, '202013016', 'Rada Intan Syafitri', 'RadaIntan@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(310, '202013017', 'Afdal Rizki', 'AfdalRizki@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(311, '202013018', 'Nur Qolbiadin Zahir', 'nurqolbiadin@poltek-kampar.ac.id', 13, 5, 'L', NULL, 'Study', 'D3', '2020 Ganjil', NULL),
(312, '202013019', 'Alwi Nopriansa', 'alwiNopriansa@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(313, '202013020', 'Anggun Dinda Pitri Milenia', 'AnggunDinda@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(314, '202013021', 'Apriana Malinda Tamba', 'aprianaMalinda@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(315, '202013022', 'Arfan PSP', 'arfan@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(316, '202013023', 'Arino', 'arinotif@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(317, '202013024', 'Atiqah Najwa Anggraini', 'AtiqahNajwa@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(318, '202013025', 'Beni Setiawan', 'beniSetiawan@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(319, '202013026', 'Della Putri Ananda', 'dellaPutri@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(320, '202013027', 'Desi Nurfitriani', 'DesiNurfitriani@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(321, '202013028', 'Diah Ayu Damayanti', 'diahayu@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(322, '202013029', 'Fahriza Ramadhan', 'fahrizaRamadhan@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(323, '202013030', 'Fajar Farhan Samosir', 'fajarFarhan@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(324, '202013031', 'Hendrianto', 'hendrianto.tif2020@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(325, '202013032', 'Isnaini Fitriati', 'isnainiFitriati@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(326, '202013033', 'Iwan', 'iwan@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(327, '202013034', 'Kefin Trifano', 'kefinTrifano@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(328, '202013035', 'Khairul Abidin', 'khairulAbidin@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(329, '202013036', 'Khuszaimah Azizah', 'khuszaimah@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(330, '202013037', 'Mhd Aulia Arief Fadillah Sormin', 'auliaArief@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(331, '202013038', 'Mulya Safitri', 'MulyaSafitri@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(332, '202013039', 'Putri Atika Dewi Kataren', 'PutriAtika@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(333, '202013040', 'Roni', 'ronitif@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(334, '202013041', 'Syafrizal', 'syafrizaltif@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(335, '202013042', 'Tri Zulham Haifani', 'TriZulham@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(336, '202013043', 'Wahyudi Lubis', 'wahyudiLubis@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(337, '202013044', 'Yohana Resty Agatha Marpaung', 'yohanaresty@poltek-kampar.ac.id', 13, 5, 'L', 17, 'Study', 'D3', '2020 Ganjil', NULL),
(338, '202013045', 'Elmalia Deliskan', 'ElmaliaDeliskan@poltek-kampar.ac.id', 13, 5, 'L', 16, 'Study', 'D3', '2020 Ganjil', NULL),
(339, '202014001', 'Bayhaqqi Lailatul Qodhar ', 'Bayhaqqi@poltek-kampar.ac.id', 14, 5, 'L', 18, 'Study', 'D4', '2020 Ganjil', NULL),
(340, '202014002', 'Claudia Elisabeth Sidabutar', 'Claudia@poltek-kampar.ac.id', 14, 5, 'L', 18, 'Study', 'D4', '2020 Ganjil', NULL),
(341, '202014003', 'Faturrahman Alhafidz', 'faturrahman@poltek-kampar.ac.id', 14, 5, 'L', 18, 'Study', 'D4', '2020 Ganjil', NULL),
(342, '202014004', 'Muhammad Alfarisi', 'alfarisi@poltek-kampar.ac.id', 14, 5, 'L', 18, 'Study', 'D4', '2020 Ganjil', NULL),
(343, '202111001', 'Ario Rusdaban', 'ariorusdaban2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(344, '202111002', 'Cici Finasti', 'cicifinasti2021.tps@students.poltek-kampar.ac.id', 11, 4, 'P', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(345, '202111003', 'Samsul Bahri', 'samsulbahri2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(346, '202111004', 'Abizar Ramadhani', 'abizarramadhani2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(347, '202111005', 'Adi Ridlha Taufiq Hidayat N.E.E', 'adiridlhataufiq2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(348, '202111006', 'Alfajri', 'alfajri2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(349, '202111007', 'Devid Satria Anugrah', 'devidsatriaanugrah2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(350, '202111008', 'Dimas Ega Wibowo', 'dimasegawibowo2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(351, '202111010', 'Fransiska Loru', 'fransiskaloru2021.tps@students.poltek-kampar.ac.id', 11, 3, 'P', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(352, '202111011', 'Indra Hasan Wirayuda', 'indrahasanwirayuda2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(353, '202111012', 'Insan Mujahiddin', 'insanmujahidin2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(354, '202111013', 'Irdan Yusnansyah', 'irdanyusnansyah2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(355, '202111014', 'Muhammad Fahim Royan ', 'muhammadfahimroyan2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(356, '202111016', 'Muhazzir Aldian Panjaitan', 'muhazziraldianpanjaitan2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(357, '202111017', 'Patricia Aliyah', 'patriciaaliyah2021.tps@students.poltek-kampar.ac.id', 11, 3, 'P', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(358, '202111018', 'Rehandi', 'rehandi2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(359, '202111019', 'Retia Hutabarat', 'retiahutabarat2021.tps@students.poltek-kampar.ac.id', 11, 3, 'P', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(360, '202111020', 'Riyan Syahputra', 'riyansyahputra2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(361, '202111021', 'Rizki Rahman Hakim', 'rizkirahmanhakim2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(362, '202111022', 'Rizky Hikmawan', 'rizkyhikmawan2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(363, '202111023', 'Ryan Arrizal Nazri', 'yanarrizalnazri2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(364, '202111024', 'Salsabila Novira', 'salsabilanovira2021.tps@students.poltek-kampar.ac.id', 11, 3, 'P', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(365, '202111025', 'Tomi Arisky Naibaho', 'tomiariskynaibaho2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(366, '202111026', 'Zulfikri', 'zulfikri2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 19, 'Study', 'D3', '2021 Ganjil', NULL),
(367, '202111027', 'A. Taufiqil Fadhilah', 'a.taufiqilfadhilah2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(368, '202111028', 'Afrizal Linardi', 'afrizallinardi2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(369, '202111029', 'Ahmad Alhanif', 'ahmadalhanif2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(370, '202111030', 'Ahmad Roihan Alpiko', 'ahmadroihanalpiko2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(371, '202111031', 'Ahmad Shodik', 'ahmadshodik2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(372, '202111032', 'Alfin Istiawan', 'alfinistiawan2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(373, '202111033', 'Arif Joni Malindo', 'arifjonimalindo2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(374, '202111034', 'Aziz Rahman Tambunan', 'azizrahmantambunan2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(375, '202111035', 'Bayu Andrian', 'bayuandrian2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(376, '202111036', 'Estom Davinci Yosia Nadeak', 'estomdavinciyosianadeak2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(377, '202111037', 'Fajar Setia Bhakti', 'fajarsetiabhakti2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(378, '202111038', 'Iyan Bastian Sianipar', 'iyanbastiansianipar2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(379, '202111039', 'M. Ikbal', 'm.ikbal2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(380, '202111040', 'M. Rifi Hamdani', 'm.rifihamdani2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(381, '202111041', 'Mahendra', 'mahendramahendra2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(382, '202111042', 'Milleven Togap Gabriel Simbolon', 'milleventogap2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(383, '202111043', 'Muhammad Habib Luthfi', 'muhammadhabibluthfi2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(384, '202111044', 'Muhammad Zaul Hazim', 'muhammadzaulhazim2021.tps@students.poltek-kampar.ac.id', 11, 3, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(385, '202111045', 'Rapi Al Qolbi', 'rapialqolbi2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(386, '202111046', 'Raywandi Almubdi', 'raywandialmubdi2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(387, '202111047', 'Roy Harianto Sihombing', 'royhariantosihombing2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(388, '202111048', 'Samuel Pandapotan Nainggolan', 'samuel2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(389, '202111049', 'Suwarno', 'suwarno2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(390, '202111050', 'Windu Guritno', 'winduguritno2021.tps@students.poltek-kampar.ac.id', 11, 4, 'L', 20, 'Study', 'D3', '2021 Ganjil', NULL),
(391, '202111051', 'Syarwindi', 'syarwindi2021.tps@students.poltek-kampar.ac.id', 11, 4, 'P', 20, 'Study', 'D3', '2021 Ganjil', NULL);
INSERT INTO `tb_mahasiswa` (`id_mhs`, `nim`, `nama`, `email`, `prodi_id`, `semester_id`, `jenis_k`, `kelas_id`, `status_study`, `jenjang_study`, `semester_awal`, `foto`) VALUES
(392, '202112001', 'Azhar Maulana', 'azharmaulana2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(393, '202112002', 'Bima Pramana', 'bimapramana2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(394, '202112003', 'Nurmukbin', 'nurmukbin2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(395, '202112004', 'Ariya', 'ariya2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(396, '202112005', 'Fadhil Hidayat', 'fadhilhidayat2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', NULL, 'Study', 'D3', '2021 Ganjil', NULL),
(397, '202112006', 'Muhammad Insan Rahman', 'insanrahman2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(398, '202112007', 'Muhammad Wahyuda', 'wahyuda2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(399, '202112008', 'Rahmad Zulfadly Dongoran', 'rahmadzulfadly2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(400, '202112009', 'Rahmat Hidayat', 'rahmathidayat2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(401, '202112010', 'Rehan', 'rehan2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(402, '202112011', 'Tulus Aldi Wiguna', 'tulusaldiwiguna2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 21, 'Study', 'D3', '2021 Ganjil', NULL),
(403, '202112012', 'Alfontus Hutapea', 'alfontushutapea2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(404, '202112013', 'Alparet Hutagalung', 'alparethutagalung2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(405, '202112014', 'Ansor Muhammad Nasution', 'ansormuhammadnasution2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(406, '202112015', 'Ari Irawan', 'ariirawan2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(407, '202112016', 'Dede Supriatna', 'dedesupriatna2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(408, '202112017', 'Dendi Tri Kurniawan', 'denditrikurniawan2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(409, '202112018', 'Fajar April Fakanza', 'fajaraprilfakanza2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(410, '202112019', 'Irdansyah', 'irdansyah2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(411, '202112020', 'Irpan Alamsyah', 'irpanalamsyah2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(412, '202112021', 'Lutfi Alfiansyah', 'lutfialfiansyah2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(413, '202112023', 'Muhammad Asrofi', 'muhamadasrofi2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(414, '202112024', 'Muhammad Adi Maulana', 'muhammadadimaulana2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(415, '202112025', 'Muhammad Doiwan Muchlis', 'muhammaddoiwanmuchlis2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(416, '202112026', 'Nur Arif Setiawan', 'nurarifsetiawan2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(417, '202112027', 'Psalmen Halomoan Sihotang', 'psalmenhalomoansihotang2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(418, '202112028', 'Raihan Maulana', 'raihanmaulana2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(419, '202112029', 'Rendi', 'rendi2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(420, '202112030', 'Riduan Syah', 'riduansyah2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(421, '202112031', 'Risky Ramadani', 'riskyramadani2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(422, '202112032', 'Roji Pramanta', 'rojipramanta2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(423, '202112033', 'Stevanus G.N. Girbes', 'stefanusggirbes2021.ppm@students.poltek-kampar.ac.id', 12, 3, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(424, '202112034', 'Suhaili', 'suhaili2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(425, '202112035', 'Thohir Afgani', 'thohirafgani2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(426, '202112036', 'Yuda Lisyandi', 'yudalisyandi2021.ppm@students.poltek-kampar.ac.id', 12, 4, 'L', 22, 'Study', 'D3', '2021 Ganjil', NULL),
(427, '202113001', 'Abdulah Bambang', 'abdulahbambang2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 23, 'Study', 'D3', '2021 Ganjil', NULL),
(428, '202113002', 'Friska Amelia Vega', 'friskaameliavega2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 23, 'Study', 'D3', '2021 Ganjil', NULL),
(429, '202113003', 'Salsabilah Syahdaniah BR Damanik', 'salsabilahsyahdaniah2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 23, 'Study', 'D3', '2021 Ganjil', NULL),
(430, '202113004', 'Wahyu Septianingsih', 'wahyuseptianingsih2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 23, 'Study', 'D3', '2021 Ganjil', NULL),
(431, '202113005', 'Bintang Amri Putra', 'bintangamriputra2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 23, 'Study', 'D3', '2021 Ganjil', NULL),
(432, '202113006', 'Mustika Delima', 'mustikadelima2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 23, 'Study', 'D3', '2021 Ganjil', NULL),
(433, '202113007', 'Lathifah Fiba Hasanah', 'lathifahfibahasanah2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 23, 'Study', 'D3', '2021 Ganjil', NULL),
(434, '202113008', 'Ade Syefira Rizky', 'adesyefirarizky2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(435, '202113009', 'Alhafidz Mukras', 'alhafidzmukras2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(436, '202113010', 'Betti Natalia Nahampun', 'bettinatalianahampun2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(437, '202113011', 'Dela Novia Utami', 'delanoviautami2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(438, '202113012', 'Rikaana Linda', 'rikaanalinda2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(439, '202113013', 'Desrita Erniati', 'desritaerniati2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(440, '202113014', 'Dhea Fernanda', 'dheafernanda2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(441, '202113015', 'Diana Oktafiani', 'dianaoktafiani2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(442, '202113016', 'Diki Wahyudy', 'dikkiwahyudi2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(443, '202113017', 'Hennita Gultom', 'hennitagultom2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(444, '202113018', 'Jami\'ah', 'jamiah2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(445, '202113019', 'Lestari Sahfitri', 'lestarisahfitri2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(446, '202113020', 'Marlina Waty Br Lubis', 'marlinawatybrlubis2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(447, '202113021', 'Maulana Alfarel', 'maulanaalfarel2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(448, '202113022', 'Muhammad Abdurraman Alfatah', 'muhammadabdurrahmanalfatah2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(449, '202113023', 'Niken Astriz Laguna', 'nikenastrizlaguna2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(450, '202113024', 'Nur Haliza', 'nurhaliza2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(451, '202113025', 'Pawel Siallagan', 'pawelsiallagan2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(452, '202113026', 'Puja Hermawati', 'pujahermawati2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(453, '202113027', 'Rahmadina Sitorus', 'rahmadinasitorus2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(454, '202113028', 'Riyadho Tahira Tunnisa', 'riyadhotahiratunnisa2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(455, '202113029', 'Rizky Firmansyah', 'rizkyfirmansyah2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(456, '202113030', 'Romi Irawan', 'romiirawan2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(457, '202113031', 'Sri Ayu Indriyani', 'sriayuindriyani2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(458, '202113032', 'Tara Liana Ramadhani Putri', 'taralianaramadhaniputri2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(459, '202113033', 'Tria Ade Pertiwi', 'triaadepertiwi2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(460, '202113034', 'Wulandari', 'wulandari2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(461, '202113035', 'Yetty Vianney', 'yettyvianney2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(462, '202113036', 'Yuli Arta Sinaga', 'yuliartasinaga2021.tif@students.poltek-kampar.ac.id', 13, 3, 'P', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(463, '202113037', 'Zulkifli', 'zulkifli2021.tif@students.poltek-kampar.ac.id', 13, 3, 'L', 24, 'Study', 'D3', '2021 Ganjil', NULL),
(464, '202114002', 'Susiana Mayasari', 'susianamayasari2021.abi@students.poltek-kampar.ac.id', 14, 3, 'P', 25, 'Study', 'D4', '2021 Ganjil', NULL),
(465, '202114003', 'Yuliani', 'yuliani2021.abi@students.poltek-kampar.ac.id', 14, 3, 'P', 25, 'Study', 'D4', '2021 Ganjil', NULL),
(466, '202114004', 'Mardiah', 'mardiah2021.abi@students.poltek-kampar.ac.id', 14, 3, 'P', 25, 'Study', 'D4', '2021 Ganjil', NULL),
(467, '22322041', 'redho andika', 'redhoandika@students.poltek-kampar.ac.id', 12, 5, 'L', 14, 'Study', 'D3', '2020 Ganjil', NULL),
(468, '22321001', 'Pritty Larasati', 'pritty2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(469, '22321002', 'Riko Hadi Pratama', 'riko2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(470, '22321003', 'Dhea Tiaramaya Safitri ', 'dhea2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(471, '22321004', 'Muhammad Pajrin', 'pajrin2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(472, '22311005', 'Afif Rohmatullah', 'afif2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(473, '22311006', 'Ahmad Rizki Amanda Hasibuan', 'ahmadriziki2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(474, '22311007', 'Aldotri Heriadi', 'aldotri2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(475, '22311008', 'Anand Marco', 'anand2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(476, '22311009', 'Budi Ripandra', 'budi2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(477, '22311010', 'Chevin Pratama Saputra Siagian', 'chevin2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(478, '22311011', 'Farhan Ashleh', 'farhan2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(479, '22311012', 'Heri Wahyuni', 'heri2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(480, '22311013', 'Lipa Rahmad', 'lipa2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(481, '22311014', 'M. Rayhan Rosivel', 'rayhan2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(482, '22311015', 'Pebredo Insar Harahap', 'pebredo2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(483, '22311016', 'Rahmat Gideon Sinaga', 'rahmatg2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(484, '22311017', 'Rian Ardy Aprilian Syah', 'rian2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(485, '22311018', 'Sujarwo Mahendro', 'sujarwo2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(486, '22311019', 'Yuda Pratama', 'yudapratama2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(487, '22311020', 'Zulfairi', 'zulfairi2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(488, '22311021', 'Zulia Khairi Mardiva', 'mardiva2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(489, '22311022', 'Asra Lukman', 'asra2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 26, 'Study', 'D3', '2022 Ganjil', NULL),
(490, '22321023', 'Aldi Ahmad Siregar', 'aldiahmad2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(491, '22321024', 'Daniel Gultom', 'danielgultom2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(492, '22321025', 'David Simbora Saragi Siadari', 'david2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(493, '22321026', 'Defri Aldi', 'defri2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(494, '22321027', 'Dicky Dharma Pratama', 'pratama2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(495, '22321028', 'Dina Yanti Br Ginting', 'dinayanti2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(496, '22321029', 'Fairuz Rizki Rafif', 'rafif2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(497, '22321030', 'Gideon Parlindungan Sihombing', 'sihombing2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(498, '22321031', 'Heral Marwan', 'heral2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(499, '22321032', 'Imam Ghozali Munthe', 'munthe2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(500, '22321033', 'Leonardo Pangaribuan', 'leonardo2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(501, '22321034', 'M. Vicki Saputra', 'saputra2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(502, '22321035', 'Muhammad Fadil Al Akbar', 'fadil2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(503, '22321036', 'Muhammad Ihsan Baja', 'ihsan2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(504, '22321037', 'Nurliza Putri Ismanto', 'nurliza2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(505, '22321038', 'Putri Fatmala', 'putri2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(506, '22321039', 'Raditiya Ramdani', 'raditiya2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(507, '22321040', 'Rahma Sari Nasution', 'rahma2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(508, '22321041', 'Rajudin', 'rajudin2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(509, '22321042', 'Razoki Anhar Bakar', 'razoki2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(510, '22321043', 'Riki Prayetno', 'riki2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(511, '22321044', 'Riky Ananda Siregar', 'riky2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(512, '22321045', 'Robby Fachri Aulia', 'aulia2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(513, '22321046', 'Surya Febrianti', 'surya202.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(514, '22321047', 'Syahrul Ikhsan Nugraha', 'nugraha2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(515, '22321048', 'Yessy Anzelika Br. Saragih', 'yessy2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(516, '22321049', 'Yolla Aulia Witri', 'witri2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(517, '22321050', 'Yudha Aditya', 'yudha2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(518, '22321051', 'Yulius Mahendra', 'yulius2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(519, '22321052', 'Sugian', 'sugian2022.tps@students.poltek-kampar.ac.id', 11, 1, 'L', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(520, '22321053', 'Risalatul Halimah', 'risalatul2022.tps@students.poltek-kampar.ac.id', 11, 1, 'P', 27, 'Study', 'D3', '2022 Ganjil', NULL),
(521, '22322001', 'Aldi Suriyanda', 'aldi2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(522, '22322002', 'Mohammad Rendy Setiawan', 'setiawan2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(523, '22322003', 'Aryadi Saputra', 'aryadi2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(524, '22322004', 'Ahmad Rifa\'i', 'ahmad2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(525, '22322005', 'Adiwal Putra', 'adiwal2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(526, '22322006', 'Danilo Fernando', 'danilo2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(527, '22312007', 'Denny Andriansyah', 'denny2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(528, '22312008', 'Fachri Legi Pratomo', 'pratomo2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(529, '22312009', 'Fauzan Dafa Rifqi', 'rifqi2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(530, '22312010', 'Habibullah', 'habibullah2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 28, 'Study', 'D3', '2022 Ganjil', NULL),
(531, '22322011', 'Ahmad Adzhhar', 'ahmadadzhar2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(532, '22322012', 'Andre Ansyah Purba', 'andre2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(533, '22322013', 'Andre Ibrahim', 'andreibrahim2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(534, '22322014', 'Arif Ardianto', 'arif2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(535, '22322015', 'Deni Syahputra Bako', 'deni2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(536, '22322016', 'Doni Bernando Simarmata', 'doni2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(537, '22322017', 'Emanuel Ridho', 'emanuel2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(538, '22322018', 'Febry Irawan', 'febry2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(539, '22322019', 'Iqbal Mustafa', 'iqbalmustafa2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(540, '22322020', 'Iqbal Satria Kelana', 'kelana2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(541, '22322021', 'Meldi Saputra', 'meldi2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(542, '22322022', 'Muhammad Abdul Gani', 'gani2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(543, '22322023', 'Muhammad Alfarizy Onra', 'onra2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(544, '22322024', 'Muhammad Iqbal Ferdinand', 'ferdinand2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(545, '22322025', 'Muhammad Nuzul Alfahreza', 'alfahreza2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(546, '22322026', 'Nathan Dwi Prayekti', 'prayekti2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(547, '22322027', 'Niken Dinda Yovita', 'yovita2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'P', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(548, '22322028', 'Novan Yuliansyah', 'novan2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(549, '22322029', 'Novelinda', 'novelinda2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'P', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(550, '22322030', 'Nur Kholid Najif', 'najif2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(551, '22322031', 'Phuspita Ratna Sari', 'sari2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'P', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(552, '22322032', 'Reza Pranata Tarigan', 'reza2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(553, '22322033', 'Rini Arlina Sitorus', 'rini2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'P', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(554, '22322034', 'Roland Wisnu Firmansyah Sirait', 'roland2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(555, '22322035', 'Sabiluraji', 'sabiluraji2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(556, '22322036', 'Stefanus Dicky Elson Siallagan', 'stefanus2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(557, '22322037', 'Vanes Revano', 'vanes2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(558, '22322038', 'Vita Febriyanti', 'vita2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'P', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(559, '22322039', 'Yuda Anasta', 'yudaanasta2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(560, '22322040', 'Zeki Pratama', 'zeki2022.ppm@students.poltek-kampar.ac.id', 12, 1, 'L', 29, 'Study', 'D3', '2022 Ganjil', NULL),
(561, '22323001', 'Juni Anggraini', 'juni2022.tif@poltek-kampar.ac.id', 13, 1, 'P', 30, 'Study', 'D3', '2022 Ganjil', NULL),
(562, '22323002', 'Erika Syafitri', 'erika2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 30, 'Study', 'D3', '2022 Ganjil', NULL),
(563, '22323003', 'Mardila Rizky Safitri ', 'safitri2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 30, 'Study', 'D3', '2022 Ganjil', NULL),
(564, '22323004', 'Nadila Darmawan', 'nadila2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 30, 'Study', 'D3', '2022 Ganjil', NULL),
(565, '22323005', 'Nurul Rejeki', 'nurul2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 30, 'Study', 'D3', '2022 Ganjil', NULL),
(566, '22323006', 'Dhea Syaiful', 'dhea2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 30, 'Study', 'D3', '2022 Ganjil', NULL),
(567, '22313007', 'Eka Agustina Pusung', 'eka2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 30, 'Study', 'D3', '2022 Ganjil', NULL),
(568, '22313008', 'Ilma Widya Agustin', 'agustin2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 30, 'Study', 'D3', '2022 Ganjil', NULL),
(569, '22323009', 'Anishah Kartari', 'anishah2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(570, '22323010', 'Ayu Puspita Sari', 'sari2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(571, '22323011', 'Dewi Theresia Panjaitan', 'dewi2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(572, '22323012', 'Dinda Dwi Wanni Putri', 'dindadwi2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(573, '22323013', 'Eko Misbahul Anam', 'eko2022.tif@students.poltek-kampar.ac.id', 13, 1, 'L', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(574, '22323014', 'Eva Fazria', 'eva2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(575, '22323015', 'Fadilah Utami', 'fadilah2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(576, '22323016', 'Ines Haya Mumtazah', 'mumtazah2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(577, '22323017', 'Jonatami Maif Rezi', 'rezi2022.tif@students.poltek-kampar.ac.id', 13, 1, 'L', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(578, '22323018', 'Khanifah Choirul Ummah', 'ummah2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(579, '22323019', 'Khoirul Adlin Hasibuan', 'khoirul2022.tif@students.poltek-kampar.ac.id', 13, 1, 'L', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(580, '22323020', 'Lidia Sepianti', 'lidia2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(581, '22323021', 'Lucky Boy Pandapotan', 'lucky2022.tif@students.poltek-kampar.ac.id', 13, 1, 'L', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(582, '22323022', 'Matjen Al Farizi Siregar', 'farizi2022.tif@students.poltek-kampar.ac.id', 13, 1, 'L', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(583, '22323023', 'Miranti', 'miranti2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(584, '22323024', 'Najwa Auliyah', 'najwa2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(585, '22323025', 'Nanda Afriani', 'nanda2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(586, '22323026', 'Nurhidayah Novitasari', 'nurhidayah2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(587, '22323027', 'Nurul Amelia', 'nurulamelia2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(588, '22323028', 'Puteri Yohana Br Sitompul', 'puteri2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(589, '22323029', 'Ratu Natalia Marjani Ufayrah', 'ratunatalia2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(590, '22323030', 'Reiza Bias Utama', 'reiza2022.tif@students.poltek-kampar.ac.id', 13, 1, 'L', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(591, '22323031', 'Retno Anggraini', 'retno2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(592, '22323032', 'Rozik Maulana', 'rozik2022.tif@students.poltek-kampar.ac.id', 13, 1, 'L', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(593, '22323033', 'Sanda Haiki', 'sanda2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(594, '22323034', 'Suci Wulan Dari', 'suci2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(595, '22323035', 'Videa Nurjanah', 'videa2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(596, '22323036', 'Vinka Nayla', 'vinka2022.tif@students.poltek-kampar.ac.id', 13, 1, 'P', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(597, '22323037', 'Yogi Anggara', 'yogianggara2022.tif@students.poltek-kampar.ac.id', 13, 1, 'L', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(598, '22323038', 'Yogi Sepdu Dehiya', 'dehiya2022.tif@students.poltek-kampar.ac.id', 13, 1, 'L', 31, 'Study', 'D3', '2022 Ganjil', NULL),
(599, '22424001', 'Wirdatul Arfifa', 'wirdatul2022.abi@students.poltek-kampar.ac.id', 14, 6, 'P', 32, 'Study', 'D4', '2022 Ganjil', NULL),
(600, '22414002', 'Alrasyidi Alwi', 'alrasyidi2022.abi@students.poltek-kampar.ac.id', 14, 1, 'L', 32, 'Study', 'D4', '2022 Ganjil', NULL),
(601, '22414003', 'Annisa Cahyani', 'annisa2022.abi@students.poltek-kampar.ac.id', 14, 1, 'P', 32, 'Study', 'D4', '2022 Ganjil', NULL),
(602, '22414004', 'Denis Ramadhan', 'denis2022.abi@students.poltek-kampar.ac.id', 14, 1, 'L', 32, 'Study', 'D4', '2022 Ganjil', NULL),
(603, '22414005', 'Hawa Vitria Nur Qholiva', 'hawa2022.abi@students.poltek-kampar.ac.id', 14, 1, 'P', 32, 'Study', 'D4', '2022 Ganjil', NULL),
(604, '22414006', 'Lilian Nethania Nava', 'lilian2022.abi@students.poltek-kampar.ac.id', 14, 2, 'P', 32, 'Study', 'D4', '2022 Ganjil', NULL),
(605, '22414007', 'Mariana Octora Br. Turnip', 'mariana2022.abi@students.poltek-kampar.ac.id', 14, 1, 'P', 32, 'Study', 'D4', '2022 Ganjil', NULL),
(606, '22414008', 'Winda Priyana ', 'winda2022.abi@students.poltek-kampar.ac.id', 14, 1, 'P', 32, 'Study', 'D4', '2022 Ganjil', NULL),
(607, '22414009', 'Yogi', 'yogi2022.abi@students.poltek-kampar.ac.id', 14, 1, 'L', 32, 'Study', 'D4', '2022 Ganjil', NULL),
(608, '22225001', 'Adil Dinata', 'adil2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(609, '22225002', 'Ahmad Zulfan', 'ahmad2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(610, '22225003', 'Akcha Ramadiyansah Lubis', 'akcha2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(611, '22225004', 'Bagus Wiranata', 'bagus2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(612, '22225005', 'Buce Werimon', 'buce2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(613, '22225006', 'Desi Horota', 'desi2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'P', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(614, '22225007', 'Dio Nugraha Sinaga', 'dio2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(615, '22225008', 'Eshau Aprilian', 'eshau2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(616, '22225009', 'Fauzan Ajima Marpaung', 'fauzan2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(617, '22225010', 'Fitra Fadhilla Yusuf', 'fitra2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(618, '22225011', 'Habib Fazrur Rahmadani', 'rahmadani2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(619, '22225012', 'Hafid Muzaki', 'hafid2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(620, '22225013', 'Irwando Siahaan', 'irwando2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(621, '22225014', 'Isma Halil', 'isma2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(622, '22225015', 'Marsia Putriani', 'marsia2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'P', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(623, '22225016', 'Nabil Faturrahman', 'nabil2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(624, '22225017', 'Neriyes Touver', 'neriyes2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(625, '22225018', 'Nur Salbiah Lubis', 'nur2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'P', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(626, '22225019', 'Pahmi Sinaga', 'pahmi2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(627, '22225020', 'Pitri Hidayat', 'pitri2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'P', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(628, '22225021', 'Randiansyah', 'randiansyah202.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(629, '22225022', 'Randy Wahdan Telaumbanua', 'randy2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(630, '22225023', 'Rio Afandi', 'rio2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(631, '22225024', 'Rizal Harits Firdiansah', 'firdiansah2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(632, '22225025', 'Rizky Yansyah Yusuf', 'rizky2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(633, '22225026', 'Roma Natalia Sinaga', 'roma2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'P', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(634, '22225027', 'Trie Andi Surya Zanah', 'zanah2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(635, '22225028', 'Yani Kartika', 'yani2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'P', 33, 'Study', 'D2', '2022 Ganjil', NULL),
(636, '22225029', 'Zeki Mursalim', 'zeki2022.tpks@students.poltek-kampar.ac.id', 121, 1, 'L', 33, 'Study', 'D2', '2022 Ganjil', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_peminjaman`
--

CREATE TABLE `tb_peminjaman` (
  `id_peminjaman` int(11) NOT NULL,
  `id_mahasiswa_peminjam` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `jumlah_peminjaman` int(11) NOT NULL,
  `tanggal_peminjaman` varchar(50) NOT NULL,
  `status` enum('Sedang Dipinjam','Sudah Dikembalikan') NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_peminjaman`
--

INSERT INTO `tb_peminjaman` (`id_peminjaman`, `id_mahasiswa_peminjam`, `id_barang`, `jumlah_peminjaman`, `tanggal_peminjaman`, `status`, `id_admin`) VALUES
(23, 297, 1, 1, 'Wednesday 12-April-2023 02:48:38', 'Sudah Dikembalikan', 1),
(24, 313, 21, 1, 'Wednesday 12-April-2023 03:00:01', 'Sudah Dikembalikan', 1),
(25, 210, 25, 1, 'Wednesday 12-April-2023 09:34:50', 'Sudah Dikembalikan', 1),
(26, 146, 22, 1, 'Wednesday 12-April-2023 09:38:14', 'Sudah Dikembalikan', 1),
(27, 525, 22, 1, 'Thursday 13-April-2023 14:02:24', 'Sudah Dikembalikan', 1),
(28, 210, 1, 1, 'Friday 14-April-2023 03:30:38', 'Sudah Dikembalikan', 1),
(29, 146, 22, 1, 'Friday 14-April-2023 10:46:20', 'Sudah Dikembalikan', 1),
(30, 210, 21, 1, 'Friday 14-April-2023 14:50:01', 'Sedang Dipinjam', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pengembalian`
--

CREATE TABLE `tb_pengembalian` (
  `id_pengembalian` int(11) NOT NULL,
  `id_mahasiswa_pengembali` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `jumlah_pengembalian` int(11) NOT NULL,
  `id_peminjaman` int(11) NOT NULL,
  `tanggal_pengembalian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_pengembalian`
--

INSERT INTO `tb_pengembalian` (`id_pengembalian`, `id_mahasiswa_pengembali`, `id_barang`, `jumlah_pengembalian`, `id_peminjaman`, `tanggal_pengembalian`) VALUES
(28, 297, 1, 1, 23, 'Wednesday 12-April-2023 02:53:22'),
(29, 313, 21, 1, 24, 'Wednesday 12-April-2023 03:00:12'),
(30, 310, 25, 1, 25, 'Wednesday 12-April-2023 09:35:01'),
(31, 146, 22, 1, 26, 'Wednesday 12-April-2023 09:38:23'),
(32, 105, 22, 1, 27, 'Thursday 13-April-2023 14:02:37'),
(33, 368, 1, 1, 28, 'Friday 14-April-2023 03:30:47'),
(34, 154, 22, 1, 29, 'Friday 14-April-2023 10:47:22');

-- --------------------------------------------------------

--
-- Table structure for table `tb_prodi`
--

CREATE TABLE `tb_prodi` (
  `kode_prodi` int(10) NOT NULL,
  `nama_prodi` varchar(75) NOT NULL,
  `singkatan` varchar(5) NOT NULL,
  `ketua_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tb_prodi`
--

INSERT INTO `tb_prodi` (`kode_prodi`, `nama_prodi`, `singkatan`, `ketua_id`) VALUES
(11, 'D3-Teknik Pengolahan Sawit', 'TPS', 0),
(12, 'D3-Perbaikan Dan Perawatan Mesin', 'PPM', 14),
(13, 'D3-Teknik Informatika', 'TIF', 1),
(14, 'D4-Administrasi Bisnis Internasional', 'ABI', 11),
(121, 'D2-Teknik Pengolahan Kelapa Sawit', 'TPKS', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE `tb_users` (
  `id_admin` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `foto_profil` varchar(100) NOT NULL,
  `terakhir_login` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`id_admin`, `email`, `username`, `password`, `foto_profil`, `terakhir_login`) VALUES
(1, 'admin@poltek-kampar.ac.id', 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'default.jpg', 'Saturday 08-April-2023 00:39:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_data_master`
--
ALTER TABLE `tb_data_master`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  ADD PRIMARY KEY (`id_kelas`),
  ADD KEY `jurusan_id` (`jurusan_id`),
  ADD KEY `dosen_id` (`dosen_id`);

--
-- Indexes for table `tb_mahasiswa`
--
ALTER TABLE `tb_mahasiswa`
  ADD PRIMARY KEY (`id_mhs`),
  ADD KEY `prodi_id` (`prodi_id`),
  ADD KEY `semester_id` (`semester_id`),
  ADD KEY `kelas_id` (`kelas_id`);

--
-- Indexes for table `tb_peminjaman`
--
ALTER TABLE `tb_peminjaman`
  ADD PRIMARY KEY (`id_peminjaman`),
  ADD KEY `id_barang` (`id_barang`);

--
-- Indexes for table `tb_pengembalian`
--
ALTER TABLE `tb_pengembalian`
  ADD PRIMARY KEY (`id_pengembalian`),
  ADD KEY `id_peminjaman` (`id_peminjaman`);

--
-- Indexes for table `tb_prodi`
--
ALTER TABLE `tb_prodi`
  ADD PRIMARY KEY (`kode_prodi`);

--
-- Indexes for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`id_admin`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_data_master`
--
ALTER TABLE `tb_data_master`
  MODIFY `id_barang` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tb_mahasiswa`
--
ALTER TABLE `tb_mahasiswa`
  MODIFY `id_mhs` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=637;

--
-- AUTO_INCREMENT for table `tb_peminjaman`
--
ALTER TABLE `tb_peminjaman`
  MODIFY `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tb_pengembalian`
--
ALTER TABLE `tb_pengembalian`
  MODIFY `id_pengembalian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_peminjaman`
--
ALTER TABLE `tb_peminjaman`
  ADD CONSTRAINT `tb_peminjaman_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `tb_data_master` (`id_barang`);

--
-- Constraints for table `tb_pengembalian`
--
ALTER TABLE `tb_pengembalian`
  ADD CONSTRAINT `tb_pengembalian_ibfk_1` FOREIGN KEY (`id_peminjaman`) REFERENCES `tb_peminjaman` (`id_peminjaman`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
